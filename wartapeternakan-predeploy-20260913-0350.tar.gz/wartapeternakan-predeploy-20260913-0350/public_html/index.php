<!DOCTYPE html>
<html lang="id" data-theme="light">
<head><meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="google-site-verification" content="pnckWwsnnAbVVELn58A9AkP-CipD_G7IMO6M_-Y9Mek" />
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-0DYY3PWE0R"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-0DYY3PWE0R');
</script>
<title>Puyuh — Catatan Budidaya, Telur &amp; Ransum | Warta Peternakan</title>
<meta name="description" content="Puyuh petelur (Coturnix japonica): fakta produksi, budidaya lahan sempit, ransum 20% protein, kualitas telur (Haugh unit, kerabang), penyimpanan, dan mitos — berdasar jurnal internasional.">
<link rel="canonical" href="https://wartapeternakan.xyz/">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Warta Peternakan">
<meta property="og:title" content="Puyuh — Catatan Budidaya, Telur &amp; Ransum">
<meta property="og:description" content="Puyuh petelur (Coturnix japonica): fakta produksi, budidaya, ransum, kualitas telur, penyimpanan, dan mitos — berdasar jurnal internasional.">
<meta property="og:url" content="https://wartapeternakan.xyz/">
<meta property="og:image" content="https://wartapeternakan.xyz/og-image.png">
<meta property="og:locale" content="id_ID">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Puyuh — Catatan Budidaya, Telur &amp; Ransum">
<meta name="twitter:description" content="Catatan puyuh petelur berdasar jurnal internasional: budidaya, ransum, kualitas telur, penyimpanan, mitos.">
<meta name="twitter:image" content="https://wartapeternakan.xyz/og-image.png">
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "Warta Peternakan",
  "url": "https://wartapeternakan.xyz/",
  "description": "Catatan seputar puyuh petelur: budidaya, telur, dan ransum.",
  "inLanguage": "id-ID"
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Apakah telur puyuh bikin kolesterol naik?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Tidak perlu dihindari berlebihan. Lemak telur puyuh didominasi asam lemak tak jenuh — asam oleat sekitar 40% dari total lemak (Czerwonka & Białek, 2024). Porsi dan cara masak tetap penentu."
      }
    },
    {
      "@type": "Question",
      "name": "Apakah puyuh mudah stres dan gampang mati?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Puyuh dikenal tahan penyakit dan efisien. Stres yang menurunkan produksi umumnya berasal dari kepadatan kandang berlebih; beri sekitar 200 cm persegi per ekor (El-Tarabany, 2016)."
      }
    },
    {
      "@type": "Question",
      "name": "Apakah telur puyuh harus dicuci sebelum disimpan?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Tidak. Mencuci menghilangkan kutikula pelindung di kerabang. Cukup lap kering dan simpan di lemari es untuk menjaga kesegaran (Acta Scientiarum, 2023)."
      }
    },
    {
      "@type": "Question",
      "name": "Apakah beternak puyuh butuh lahan luas?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Tidak. Puyuh cocok diternakkan di lahan sempit dengan kandang bertingkat. Satu butir telurnya setara 8% bobot tubuh induk, jauh lebih efisien daripada ayam yang hanya 3% (Bagh dkk., 2016)."
      }
    }
  ]
}
</script>
<link rel="icon" href="data:image/svg+xml,%3Csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20viewBox=%270%200%2064%2064%27%3E%3Cellipse%20cx=%2732%27%20cy=%2736%27%20rx=%2717%27%20ry=%2723%27%20fill=%27%23131311%27%20stroke=%27%23d9a441%27%20stroke-width=%273%27/%3E%3Ccircle%20cx=%2727%27%20cy=%2728%27%20r=%272.6%27%20fill=%27%23d9a441%27/%3E%3Ccircle%20cx=%2738%27%20cy=%2733%27%20r=%272%27%20fill=%27%23b4701f%27/%3E%3Ccircle%20cx=%2731%27%20cy=%2744%27%20r=%272.4%27%20fill=%27%23d9a441%27/%3E%3Ccircle%20cx=%2737%27%20cy=%2747%27%20r=%271.6%27%20fill=%27%23e8e2d2%27/%3E%3Ccircle%20cx=%2725%27%20cy=%2740%27%20r=%271.8%27%20fill=%27%23e8e2d2%27/%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="image" href="puyuh1.webp" type="image/webp">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@500;600;700&amp;family=Newsreader:ital,opsz,wght@0,6..72,500;0,6..72,600;0,6..72,700;1,6..72,500;1,6..72,600;1,6..72,700&amp;family=Source+Sans+3:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,600&amp;display=swap" rel="stylesheet">
<style>
:root{
  --bg:#10100e;
  --bg2:#17170f;
  --ink:#151515;
  --paper:#ffffff;
  --paper2:#ebf0ed;
  --mut:#626762;
  --mut-d:#6b6f6b;
  --line-w:rgba(244,241,232,.14);
  --line-w2:rgba(244,241,232,.3);
  --line-k:rgba(21,21,21,.12);
  --acc:#d9a441;
  --acc2:#95580f;
  --sage:#3d5a43;
  --inv:#f4f1e8;
  --inv-mut:rgba(244,241,232,.6);
  --sans:"Source Sans 3",system-ui,-apple-system,"Segoe UI",sans-serif;
  --serif:"Newsreader",Georgia,"Times New Roman",serif;
  --mono:"IBM Plex Mono",ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  --display:"Newsreader",Georgia,"Times New Roman",serif;
  --sp-1:8px;--sp-2:16px;--sp-3:24px;--sp-4:40px;--sp-5:64px;--sp-6:96px;
  --rad:3px;
  --shadow-1:0 1px 2px rgba(0,0,0,.05),0 2px 8px rgba(0,0,0,.04);
  --shadow-2:0 8px 30px rgba(0,0,0,.12);
  --focus:0 0 0 3px rgba(217,164,65,.45);
}
html[data-theme="dark"]{
  --ink:#f0ede4;
  --paper:#141412;
  --paper2:#1c1c18;
  --mut:#8f948f;
  --mut-d:#adb2ad;
  --line-w:rgba(244,241,232,.16);
  --line-w2:rgba(244,241,232,.32);
  --line-k:rgba(244,241,232,.14);
  --acc:#e0ab4d;
  --acc2:#d9a441;
  --sage:#6a8f72;
  --shadow-1:0 1px 2px rgba(0,0,0,.3),0 2px 10px rgba(0,0,0,.25);
  --shadow-2:0 10px 36px rgba(0,0,0,.5);
}
/* pill di section kontak selalu di atas latar gelap -> warna teksnya tetap gelap di kedua tema */
html[data-theme="dark"] .pill{color:#151515}
html[data-theme="dark"] .pill .ic{background:#151515;color:#f4f1e8}

/* ---------- theme transition (view-transition circle wipe) ---------- */
html.vt-running,html.vt-running *{transition:none!important}
@keyframes vt-fade{from{opacity:1}to{opacity:0}}
@keyframes vt-circle{
  from{clip-path:circle(0px at var(--vt-x,calc(100% - 60px)) var(--vt-y,60px))}
  to{clip-path:circle(150vmax at var(--vt-x,calc(100% - 60px)) var(--vt-y,60px))}
}
::view-transition-old(root){animation:vt-fade .3s ease both}
::view-transition-new(root){animation:vt-circle .7s cubic-bezier(.2,.6,.2,1) both}
@media(prefers-reduced-motion:reduce){
  ::view-transition-old(root),::view-transition-new(root){animation:none}
}
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
html,body{transition:background-color .5s ease,color .5s ease}
body{background:var(--paper);color:var(--ink);font-family:var(--sans);font-size:17px;line-height:1.65;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;transition:background-color .5s ease,color .5s ease}
section,h1,h2,h3,p,a,span,div,li,td,th,small,b,em,figure,figcaption,sup,table{transition:background-color .5s ease,color .5s ease,border-color .5s ease}
::selection{background:var(--acc);color:var(--ink)}
:focus-visible{outline:2px solid var(--acc);outline-offset:3px;border-radius:2px}
.skip-link{position:fixed;top:10px;left:10px;z-index:1000;background:var(--acc);color:#151515;padding:10px 14px;font-weight:800;text-decoration:none;transform:translateY(-180%);transition:transform .2s ease}
.skip-link:focus{transform:none}
.sr-only{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important}
.grain{position:fixed;inset:0;z-index:999;pointer-events:none;opacity:.055;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='160' height='160' filter='url(%23n)'/%3E%3C/svg%3E")}
.wrap{max-width:1200px;margin:0 auto;padding:0 32px}
a{color:inherit}

/* ---------- nav ---------- */
nav{
  position:fixed;top:0;left:0;right:0;z-index:200;
  transition:background .3s ease,border-color .3s ease,box-shadow .3s ease;
  border-bottom:1px solid transparent;
}
nav.scrolled{background:rgba(16,16,14,.85);backdrop-filter:blur(10px);border-bottom-color:var(--line-w);box-shadow:0 1px 20px rgba(0,0,0,.12)}
.nav-in{display:flex;align-items:center;justify-content:space-between;padding:18px 0}
.brand{display:flex;align-items:baseline;gap:12px;text-decoration:none;color:var(--inv)}
.brand b{font-weight:800;font-size:17px;letter-spacing:-.01em}
.brand span{font-family:var(--mono);font-size:9.5px;letter-spacing:.22em;text-transform:uppercase;color:var(--acc)}
.nav-links{display:flex;align-items:center;gap:30px;list-style:none}
.nav-links a{text-decoration:none;font-size:12px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--inv);opacity:.75;position:relative;padding:4px 0;transition:opacity .2s ease}
.nav-links a::after{content:"";position:absolute;left:0;bottom:0;height:1px;width:0;background:var(--acc);transition:width .25s ease}
.nav-links a:hover{opacity:1}
.nav-links a:hover::after,.nav-links a.active::after{width:100%}
.nav-links a.active{opacity:1}
.menu-btn{
  display:none;background:none;border:1px solid var(--line-w2);color:var(--inv);
  font-family:var(--mono);font-size:10px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;
  padding:9px 14px;cursor:pointer;border-radius:2px;min-height:44px;
}
.theme-btn{
  background:none;border:1px solid var(--line-w2);color:var(--inv);
  font-family:var(--mono);font-size:12px;font-weight:700;line-height:1;
  width:44px;height:44px;cursor:pointer;border-radius:50%;
  display:inline-flex;align-items:center;justify-content:center;
  transition:background .2s ease,color .2s ease,border-color .2s ease,transform .2s ease;
}
@media (hover:hover) and (pointer:fine){
  .theme-btn:hover{background:var(--acc);border-color:var(--acc);color:var(--ink)}
}
.nav-right{display:flex;align-items:center;gap:12px}
@media(max-width:1120px){
  .nav-in{padding-left:32px;padding-right:32px}
  .nav-links{display:none;position:absolute;top:100%;left:0;right:0;background:var(--bg);flex-direction:column;gap:0;padding:10px 32px 22px;border-bottom:1px solid var(--line-w)}
  .nav-links.open{display:flex}
  .nav-links a{padding:13px 0;border-bottom:1px solid var(--line-w);width:100%}
  .nav-links li:last-child a{border-bottom:none}
  .menu-btn{display:block}
}

/* ---------- hero ---------- */
.hero{
  min-height:100vh;display:flex;flex-direction:column;justify-content:center;
  background:
    linear-gradient(90deg, rgba(10,10,8,.9) 0%, rgba(10,10,8,.6) 42%, rgba(10,10,8,.22) 75%, rgba(10,10,8,.42) 100%),
    linear-gradient(180deg, rgba(10,10,8,.55) 0%, transparent 30%, transparent 62%, rgba(10,10,8,.7) 100%),
    url('puyuh1.jpg') center 22% / cover no-repeat;
  background:
    linear-gradient(90deg, rgba(10,10,8,.9) 0%, rgba(10,10,8,.6) 42%, rgba(10,10,8,.22) 75%, rgba(10,10,8,.42) 100%),
    linear-gradient(180deg, rgba(10,10,8,.55) 0%, transparent 30%, transparent 62%, rgba(10,10,8,.7) 100%),
    image-set(url('puyuh1.webp') type('image/webp'),url('puyuh1.jpg') type('image/jpeg')) center 22% / cover no-repeat;
  color:var(--inv);position:relative;overflow:hidden;
}
.hero::before{
  content:"";position:absolute;inset:0;pointer-events:none;z-index:1;
  background:
    repeating-linear-gradient(0deg, rgba(244,241,232,.028) 0 1px, transparent 1px 4px);
}
.hero::after{
  content:"";position:absolute;inset:0;pointer-events:none;z-index:0;opacity:0;
  background:
    linear-gradient(90deg, rgba(10,10,8,.9) 0%, rgba(10,10,8,.6) 42%, rgba(10,10,8,.22) 75%, rgba(10,10,8,.42) 100%),
    linear-gradient(180deg, rgba(10,10,8,.55) 0%, transparent 30%, transparent 62%, rgba(10,10,8,.7) 100%),
    url('puyuh-batu.jpg') center 22% / cover no-repeat;
  background:
    linear-gradient(90deg, rgba(10,10,8,.9) 0%, rgba(10,10,8,.6) 42%, rgba(10,10,8,.22) 75%, rgba(10,10,8,.42) 100%),
    linear-gradient(180deg, rgba(10,10,8,.55) 0%, transparent 30%, transparent 62%, rgba(10,10,8,.7) 100%),
    image-set(url('puyuh-batu.webp') type('image/webp'),url('puyuh-batu.jpg') type('image/jpeg')) center 22% / cover no-repeat;
  transition:opacity .45s cubic-bezier(.2,.6,.2,1);
}
body.sp-bt .hero::after{opacity:1}
.hero-grid{max-width:1200px;margin:auto;width:100%;padding:0 0 48px;position:relative;z-index:2;text-align:center}
.eyebrow{
  font-family:var(--mono);font-size:10.5px;font-weight:700;letter-spacing:.26em;text-transform:uppercase;
  color:var(--acc);display:flex;align-items:center;justify-content:center;gap:14px;margin-bottom:28px;
}
.eyebrow::before,.eyebrow::after{content:"";width:38px;height:1px;background:var(--acc)}
h1{
  font-family:var(--display);font-weight:700;line-height:.96;letter-spacing:-.035em;
  font-size:clamp(46px,7vw,92px);max-width:16ch;margin:0 auto;text-align:center;
}
h1 .dim{color:var(--acc);font-weight:700}
h1 em{font-style:italic;color:var(--acc);font-weight:700;letter-spacing:-.01em}
.hero-sub{margin-top:28px;max-width:52ch;color:rgba(244,241,232,.72);font-size:16px;line-height:1.75;text-shadow:0 1px 12px rgba(0,0,0,.4)}
.hero-sub b{color:var(--inv);font-weight:600}
.hero-meta{margin-top:38px;display:flex;flex-wrap:wrap;gap:12px 34px;font-family:var(--mono);font-size:10.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--inv-mut)}
.hero-meta b{color:var(--inv);font-weight:700;font-family:var(--sans);font-size:13px;letter-spacing:0}
.hero-cta{display:inline-flex;align-items:center;gap:10px;margin-top:28px;color:var(--inv);font-family:var(--mono);font-size:10px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;text-decoration:none;border-bottom:1px solid var(--acc);padding:8px 0}

.hero-art{display:none}
.hero-cards{
  grid-column:1/-1;display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:30px;
  position:relative;z-index:2;
}
.hcard{
  display:flex;align-items:center;justify-content:space-between;gap:18px;
  border:1px solid var(--line-w2);border-radius:var(--rad);padding:18px 22px;
  background:rgba(23,23,15,.55);backdrop-filter:blur(6px);text-decoration:none;
  transition:border-color .25s ease,background .25s ease,transform .25s ease,box-shadow .25s ease;
}
.hcard:hover{border-color:rgba(217,164,65,.55);background:rgba(23,23,15,.85);transform:translateY(-2px);box-shadow:var(--shadow-2)}
.hc-txt{display:flex;flex-direction:column;gap:3px}
.hc-txt b{font-size:14px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--inv)}
.hc-txt small{font-family:var(--mono);font-size:9.5px;font-weight:700;letter-spacing:.1em;color:var(--mut);text-transform:uppercase}
.hc-arr{
  width:36px;height:36px;flex:none;border-radius:50%;
  border:1px solid var(--line-w2);display:inline-flex;align-items:center;justify-content:center;
  color:var(--inv);font-size:15px;transition:background .25s ease,color .25s ease,border-color .25s ease,transform .25s ease;
}
.hcard:hover .hc-arr{background:var(--acc);border-color:var(--acc);color:var(--ink);transform:translateX(3px)}
.hero-stats{
  grid-column:1/-1;margin-top:50px;border-top:1px solid var(--line-w2);border-bottom:1px solid var(--line-w2);
  display:grid;grid-template-columns:repeat(4,1fr);position:relative;z-index:2;
}
.hstat{padding:22px 26px;border-right:1px solid var(--line-w)}
.hstat:first-child{padding-left:0}
.hstat:last-child{border-right:none;padding-right:0}
.hstat .n{font-family:var(--serif);font-weight:700;font-size:clamp(30px,3.4vw,44px);letter-spacing:-.02em;line-height:1;color:var(--inv)}
.hstat .n sup{font-size:15px;color:var(--acc);font-weight:700;margin-left:2px}
.hstat .l{font-family:var(--mono);font-size:9.5px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--mut);margin-top:10px}

/* ---------- ticker ---------- */
.ticker{
  background:var(--acc);color:#151515;
  overflow:hidden;white-space:nowrap;padding:12px 0;
}
.ticker-track{display:inline-block;animation:tick 38s linear infinite}
.ticker:hover .ticker-track,.ticker:focus .ticker-track{animation-play-state:paused}
.ticker span{
  font-family:var(--mono);font-size:11px;letter-spacing:.18em;text-transform:uppercase;
  padding:0 22px;font-weight:700;
}
.ticker .dot{color:var(--ink);opacity:.45}
@keyframes tick{from{transform:translateX(0)}to{transform:translateX(-50%)}}

/* ---------- sections ---------- */
section{padding:120px 0;scroll-margin-top:70px}
.sec-head{margin-bottom:56px}
.sec-num{
  font-family:var(--mono);font-size:11.2px;font-weight:700;letter-spacing:.24em;text-transform:uppercase;
  display:flex;align-items:center;gap:14px;color:var(--mut-d);margin-bottom:22px;
}
.sec-num .box{
  border:1px solid var(--line-k);padding:3px 8px;color:var(--ink);font-weight:700;
  display:inline-block;letter-spacing:.12em;font-size:10px;
}
.sec-num::after{content:"";flex:1;height:1px;background:var(--line-k);max-width:120px}
h2{
  font-family:var(--display);font-weight:700;letter-spacing:-.025em;line-height:1;
  font-size:clamp(38px,4.8vw,60px);max-width:20ch;
}
h2 em{font-style:italic;font-weight:700;color:var(--acc2)}
.lede{margin-top:24px;max-width:56ch;color:var(--mut-d);font-size:18px;line-height:1.6;font-weight:400}

.s-white{background:var(--paper)}
.s-paper{background:var(--paper2)}

/* about */
.about-grid{display:grid;grid-template-columns:1.55fr 1fr;gap:64px;align-items:start}
.about-copy p{margin-bottom:18px;color:var(--mut-d);font-size:17.5px;line-height:1.75}
.about-copy p b{color:var(--ink);font-weight:600}
.about-copy p strong{color:var(--ink);font-weight:700}
.fact-table{border-top:2px solid var(--ink)}
.fact-row{
  display:flex;justify-content:space-between;align-items:baseline;gap:18px;
  padding:13px 0;border-bottom:1px solid var(--line-k);font-size:15px;color:var(--mut-d);
}
.fact-row b{font-weight:700;color:var(--ink);font-family:var(--serif);font-size:19px;letter-spacing:-.01em}
.fact-row .k{font-family:var(--mono);font-size:10px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--mut-d);text-align:right;white-space:nowrap}
.fact-src{margin-top:16px;font-family:var(--mono);font-size:10.5px;color:var(--mut-d);letter-spacing:.02em;line-height:1.7}

/* steps (budidaya) */
.steps{display:grid;grid-template-columns:1fr 1fr;border:1px solid var(--ink);background:var(--paper);box-shadow:var(--shadow-1)}
.step{
  padding:38px 40px;border-bottom:1px solid var(--line-k);position:relative;min-height:250px;
  display:flex;flex-direction:column;
  transition:background .25s ease;
}
.step:hover{background:color-mix(in srgb, var(--paper2) 55%, var(--paper))}
.step:nth-child(odd){border-right:1px solid var(--line-k)}
.step:nth-last-child(-n+2){border-bottom:none}
.step .no{
  font-family:var(--mono);font-size:11px;font-weight:700;letter-spacing:.24em;color:var(--acc2);
  display:flex;align-items:center;gap:12px;margin-bottom:16px;
}
.step .no::after{content:"";flex:1;height:1px;background:var(--line-k)}
.step h3{font-weight:800;font-size:23px;letter-spacing:-.02em;margin-bottom:10px;line-height:1.15}
.step p{font-size:15.5px;color:var(--mut-d);line-height:1.7}
.step p b{color:var(--ink);font-weight:600}
.step .tag{
  position:absolute;top:38px;right:40px;
  font-family:var(--mono);font-size:9px;letter-spacing:.18em;text-transform:uppercase;
  color:var(--mut-d);border:1px solid var(--line-k);border-radius:2px;padding:3px 10px;
}

/* tables */
.tbl{border:1px solid var(--ink);background:var(--paper);overflow-x:auto;box-shadow:var(--shadow-1);scrollbar-gutter:stable}
.tbl::before{display:none}
.tbl table{width:100%;border-collapse:collapse;font-size:14px}
.tbl thead th{
  font-family:var(--mono);font-size:9.5px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;
  text-align:left;padding:15px 22px;border-bottom:1px solid var(--ink);
  background:var(--paper2);color:var(--mut-d);
}
.tbl tbody td,.tbl tbody th{padding:16px 22px;border-bottom:1px solid var(--line-k);vertical-align:top;color:var(--mut-d);font-size:15px;text-align:left;font-weight:400}
.tbl tbody tr:last-child td,.tbl tbody tr:last-child th{border-bottom:none}
.tbl tbody tr{transition:background .15s ease}
.tbl tbody tr:hover{background:rgba(217,164,65,.08)}
.tbl td b,.tbl tbody th b{color:var(--ink);font-weight:700}
.tbl-note{margin-top:16px;font-family:var(--mono);font-size:10.5px;color:var(--mut-d);letter-spacing:.02em;line-height:1.7}

.two-col{display:grid;grid-template-columns:1fr 1fr;gap:56px;margin-top:52px}
.two-col .copy p,.simpan-grid .copy p{margin-bottom:16px;color:var(--mut-d);font-size:17px;line-height:1.7}
.two-col .copy p b,.simpan-grid .copy p b{color:var(--ink);font-weight:600}

/* quality */
.quality-grid{display:grid;grid-template-columns:1fr 1.1fr;gap:70px;align-items:center}
.quality-art{
  position:relative;display:flex;align-items:center;justify-content:center;padding:40px 0;
}
.quality-art img{
  width:min(380px,80%);height:auto;display:block;
  filter:drop-shadow(0 26px 44px rgba(0,0,0,.22));
}
.q-params{border-top:2px solid var(--ink)}
.q-row{
  display:grid;grid-template-columns:1fr auto;gap:20px;align-items:baseline;
  padding:19px 0;border-bottom:1px solid var(--line-k);
}
.q-row .v{font-family:var(--serif);font-weight:700;font-size:22px;letter-spacing:-.01em;color:var(--ink)}
.q-row .v small{color:var(--acc2);font-size:12.5px;font-family:var(--mono);font-weight:700;margin-left:6px}
.q-row .k{font-family:var(--mono);font-size:9.5px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--mut-d);text-align:right}
.q-note{margin-top:18px;font-family:var(--mono);font-size:10px;color:var(--mut-d);line-height:1.7}

/* tips */
.tips{list-style:none;border-top:2px solid var(--ink)}
.tips li{
  padding:12px 0;border-bottom:1px solid var(--line-k);
  display:grid;grid-template-columns:36px 1fr;gap:10px;align-items:baseline;
  font-size:15.5px;color:var(--mut-d);line-height:1.6;
}
.tips .no{font-family:var(--serif);font-style:italic;font-weight:600;font-size:17px;color:var(--acc2)}
.tips b{color:var(--ink);font-weight:600}
.tips-block{margin-top:48px}
.tips-title{
  font-family:var(--mono);font-size:11px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;
  color:var(--mut-d);margin-bottom:18px;display:flex;align-items:center;gap:14px;
}
.tips-title::after{content:"";flex:1;height:1px;background:var(--line-k);max-width:240px}
/* simpan: paragraf kiri + tips kanan sejajar */
.simpan-grid{display:grid;grid-template-columns:1.2fr 1fr;gap:64px;align-items:start}
.simpan-grid .tips-block{margin-top:0}

/* myth vs fact */
.myth{border-top:2px solid var(--ink)}
.myth-row{
  display:grid;grid-template-columns:1fr 1.4fr;gap:56px;
  padding:34px 0;border-bottom:1px solid var(--line-k);align-items:start;
}
.myth-label,.fact-label{font-family:var(--mono);font-size:9.5px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;display:block;margin-bottom:12px}
.myth-label{color:var(--mut-d)}
.myth-label .x{color:var(--acc2);margin-right:6px}
.fact-label{color:var(--acc2)}
.fact-label .chk{margin-right:6px}
.myth p{font-size:17px;color:var(--mut-d);text-decoration:line-through;text-decoration-color:var(--line-k);text-decoration-thickness:1px;line-height:1.6;font-weight:500}
.fact p{font-size:16px;color:var(--mut-d);line-height:1.7}
.fact p b{color:var(--ink);font-weight:700}
.fact .src{display:block;margin-top:10px;font-family:var(--mono);font-size:9.5px;font-weight:700;letter-spacing:.08em;color:var(--acc2)}

/* references */
.refs{list-style:none;counter-reset:ref;border-top:2px solid var(--ink)}
.refs li{
  counter-increment:ref;position:relative;
  padding:13px 0 13px 52px;border-bottom:1px solid var(--line-k);
  font-size:14.5px;color:var(--mut-d);line-height:1.65;
}
.refs li::before{
  content:counter(ref);position:absolute;left:0;top:13px;
  font-family:var(--mono);font-size:11px;font-weight:700;color:var(--acc2);
  border:1px solid var(--line-k);border-radius:2px;padding:2px 8px;
}
.refs li em{color:var(--ink);font-style:italic}

/* contact CTA */
.contact{
  background:
    radial-gradient(900px 500px at 20% 80%, rgba(217,164,65,.08), transparent 55%),
    var(--paper2);
  color:var(--ink);text-align:center;padding:140px 0;
  border-top:1px solid var(--line-k);border-bottom:1px solid var(--line-k);
}
.contact .small{
  font-family:var(--mono);font-size:10px;font-weight:700;letter-spacing:.26em;text-transform:uppercase;color:var(--acc);
  display:inline-flex;align-items:center;gap:12px;margin-bottom:30px;
}
.contact .small::before,.contact .small::after{content:"";width:34px;height:1px;background:var(--acc)}
.contact h2{
  font-size:clamp(34px,5vw,64px);max-width:16ch;margin:0 auto;
}
.contact h2 em{font-style:italic;font-family:var(--serif);font-weight:500;color:var(--acc2)}
.contact .sub{margin:24px auto 44px;max-width:44ch;color:var(--mut-d);font-size:15.5px;line-height:1.7}
.pill{
  display:inline-flex;align-items:center;gap:14px;text-decoration:none;
  background:var(--inv);color:var(--ink);font-weight:700;font-size:13px;letter-spacing:.14em;text-transform:uppercase;
  padding:18px 26px 18px 30px;border-radius:999px;transition:transform .2s ease,background .2s ease,box-shadow .2s ease;
}
.pill .ic{
  width:30px;height:30px;border-radius:50%;background:var(--ink);color:var(--inv);
  display:inline-flex;align-items:center;justify-content:center;font-size:13px;
}
.pill:hover{transform:translateY(-2px);box-shadow:var(--shadow-2)}
.pill:hover .ic{background:var(--acc);color:var(--ink)}
.contact .footnote{margin-top:26px;font-family:var(--mono);font-size:10px;letter-spacing:.12em;color:var(--mut-d);text-transform:uppercase}

/* feedback form */
.fb-form{border:1px solid var(--ink);background:var(--paper);padding:36px 38px;position:relative;box-shadow:var(--shadow-1)}
.fb-hp{position:absolute;left:-9999px;top:0;width:1px;height:1px;opacity:0;overflow:hidden}
.fb-grid{display:grid;grid-template-columns:1fr 1fr;gap:22px;margin-bottom:22px}
.fb-field{display:block}
.fb-field span{display:flex;gap:8px;font-family:var(--mono);font-size:9.5px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--mut-d);margin-bottom:9px}
.fb-field span i{font-style:normal;color:var(--mut);text-transform:none;letter-spacing:0;font-family:var(--sans);font-size:12px;font-weight:400}
.fb-field input,.fb-field textarea{
  width:100%;background:var(--paper2);border:1px solid var(--line-k);border-radius:2px;
  color:var(--ink);font-family:var(--sans);font-size:16px;padding:12px 14px;outline:none;
  transition:border-color .2s ease,background .2s ease,box-shadow .2s ease;
}
.fb-field input::placeholder,.fb-field textarea::placeholder{color:var(--mut)}
.fb-field input:focus,.fb-field textarea:focus{border-color:var(--acc2);box-shadow:var(--focus)}
.fb-field textarea{resize:vertical;min-height:130px}
.fb-foot{display:flex;align-items:center;gap:20px;margin-top:26px;flex-wrap:wrap}
.fb-btn{
  background:var(--ink);color:var(--paper);border:1px solid var(--ink);
  font-family:var(--mono);font-size:11px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;
  padding:14px 24px;cursor:pointer;border-radius:2px;transition:background .2s ease,color .2s ease,transform .2s ease,box-shadow .2s ease;
  min-height:44px;
}
.fb-btn:hover{background:var(--acc);border-color:var(--acc);color:var(--ink);transform:translateY(-1px);box-shadow:var(--shadow-1)}
.fb-status{font-family:var(--mono);font-size:10.5px;color:var(--acc2);letter-spacing:.04em}
.fb-status.err{color:#c0392b}
@media(max-width:600px){.fb-grid{grid-template-columns:1fr}.fb-form{padding:26px 22px}}

/* footer */
footer{background:#0a0a08;color:var(--inv);border-top:1px solid var(--line-w)}
.foot-in{padding:64px 0 44px;display:grid;grid-template-columns:1.5fr 1fr 1fr;gap:56px}
.foot-brand b{font-weight:800;font-size:22px;letter-spacing:-.02em}
.foot-brand .sub{font-family:var(--mono);font-size:9px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--acc);display:block;margin-top:8px}
.foot-brand p{color:rgba(244,241,232,.55);font-size:13.5px;margin-top:14px;max-width:36ch;line-height:1.7}
.foot-col h3{font-family:var(--mono);font-size:9.5px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;color:var(--acc);margin-bottom:18px}
.foot-col ul{list-style:none}
.foot-col li{margin-bottom:10px}
.foot-col a{color:rgba(244,241,232,.65);text-decoration:none;font-size:13.5px;transition:color .2s ease}
.foot-col a:hover{color:var(--paper)}
.foot-base{
  border-top:1px solid var(--line-w);padding:20px 0;
  display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap;
  font-family:var(--mono);font-size:10px;letter-spacing:.12em;color:rgba(244,241,232,.35);text-transform:uppercase;
}

.reveal{opacity:0;transform:translateY(24px);transition:opacity .8s cubic-bezier(.2,.6,.2,1),transform .8s cubic-bezier(.2,.6,.2,1)}
.reveal.in{opacity:1;transform:none}
.reveal.d1{transition-delay:.08s}
.reveal.d2{transition-delay:.16s}
.reveal.d3{transition-delay:.24s}

/* ---------- hero entrance ---------- */
body.intro-done .eyebrow{animation:rise .9s cubic-bezier(.16,1,.3,1) .05s both}
body.intro-done h1{animation:rise 1s cubic-bezier(.16,1,.3,1) .15s both}
body.intro-done .hero-sub{animation:rise 1s cubic-bezier(.16,1,.3,1) .3s both}
body.intro-done .hero-meta{animation:rise 1s cubic-bezier(.16,1,.3,1) .45s both}
body.intro-done .hero-cards{animation:rise 1s cubic-bezier(.16,1,.3,1) .6s both}
body.intro-done .hero-stats{animation:rise 1s cubic-bezier(.16,1,.3,1) .75s both}
@keyframes rise{
  from{opacity:0;transform:translateY(34px);filter:blur(6px)}
  to{opacity:1;transform:none;filter:blur(0)}
}

/* arrows */
.arr{display:inline-block;transition:transform .25s ease}
a:hover .arr{transform:translate(3px,-3px)}

@media(max-width:980px){
  .hero-grid{grid-template-columns:1fr;gap:48px;padding-top:110px}
  .hero-stats{grid-template-columns:repeat(2,1fr)}
  .hstat:nth-child(2){border-right:none}
  .hstat:nth-child(n+3){border-top:1px solid var(--line-w)}
  .hstat:nth-child(3){border-left:none}
  .about-grid{grid-template-columns:1fr;gap:36px}
  .quality-grid{grid-template-columns:1fr;gap:40px}
  .two-col{grid-template-columns:1fr;gap:30px;margin-top:36px}
  .myth-row{grid-template-columns:1fr;gap:20px}
  .steps{grid-template-columns:1fr}
  .step:nth-child(odd){border-right:none}
  .step:nth-last-child(-n+2){border-bottom:1px solid var(--line-k)}
  .step:last-child{border-bottom:none}
  .foot-in{grid-template-columns:1fr;gap:38px}
  .tag-float.t2{right:0}
}
@media(max-width:600px){
  html,body{overflow-x:clip}
  .wrap{padding:0 22px}
  .brand span{display:none}
  .brand b{white-space:nowrap}
  section{padding:76px 0}
  .hero-stats{grid-template-columns:1fr 1fr}
  .hstat{padding:18px 16px}
  .hstat:first-child{padding-left:0}
  .hero-cards{grid-template-columns:1fr}
  .step{padding:30px 26px;min-height:0}
  .step .tag{position:static;display:inline-block;margin-bottom:14px}
  .contact{padding:100px 0}
  .tbl::before{
    content:"Geser tabel ke samping  \2192";position:sticky;left:0;z-index:2;display:block;width:max-content;
    padding:8px 12px;background:var(--acc);color:#151515;font-family:var(--mono);font-size:9px;
    font-weight:700;letter-spacing:.14em;text-transform:uppercase
  }
  .tbl table{min-width:620px}
  .simpan-grid{grid-template-columns:1fr;gap:30px}
  .pill{width:100%;min-width:0;justify-content:space-between;font-size:10.5px;letter-spacing:.08em;padding:15px 14px 15px 18px}
  .foot-base{flex-direction:column;gap:8px}
}
@media(max-width:360px){
  .wrap{padding-left:16px;padding-right:16px}
  .brand b{font-size:15px;white-space:nowrap}
  .nav-in{gap:8px}
  .menu-btn{padding:9px 10px}
  .sp-pick{display:flex;flex-direction:column;align-items:stretch;width:100%;max-width:100%}
  .sp-pick select{width:100%;max-width:100%;font-size:10px;padding-left:12px}
}
@media(prefers-reduced-motion:reduce){
  *,*::before,*::after{animation:none!important;transition:none!important}
  html{scroll-behavior:auto}
  .reveal{opacity:1;transform:none}
}

/* ---------- pemilih jenis puyuh (dropdown hero) ---------- */
.sp-pick{
  margin-top:34px;display:inline-flex;align-items:center;gap:12px;
  font-family:var(--mono);font-size:10.5px;letter-spacing:.16em;text-transform:uppercase;color:var(--inv-mut);
}
.sp-pick select{
  background:rgba(16,16,14,.6);border:1px solid var(--line-w2);color:var(--inv);
  font-family:var(--mono);font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;
  padding:12px 38px 12px 16px;border-radius:2px;cursor:pointer;outline:none;appearance:none;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23d9a441' stroke-width='2' fill='none'/%3E%3C/svg%3E");
  background-repeat:no-repeat;background-position:right 14px center;
  transition:border-color .2s ease,background .2s ease;
}
.sp-pick select:hover{border-color:rgba(217,164,65,.6)}
.sp-pick select:focus-visible{box-shadow:var(--focus)}
.sp-pick option{background:#17170f;color:var(--inv)}
/* toggle konten per jenis */
.sp-bt{display:none}
body.sp-bt{display:block} /* override .sp-bt untuk body — jangan sembunyikan body */
body.sp-bt .sp-jp{display:none}
body.sp-bt .sp-bt{display:block}
/* elemen yang butuh display non-block saat tampil */
body.sp-bt .eyebrow.sp-bt{display:flex}
body.sp-bt .ticker-track.sp-bt{display:inline-block}


</style>
</head>
<body>
<a class="skip-link" href="#main-content">Lewati ke isi utama</a>
<div class="grain"></div>

<nav id="topnav">
  <div class="wrap nav-in">
    <a class="brand" href="#top"><b>Warta Peternakan</b><span>puyuh &amp; telur</span></a>
    <button class="menu-btn" id="menuBtn" aria-label="Buka menu" aria-controls="navLinks" aria-expanded="false">Menu &#9776;</button>
    <ul class="nav-links" id="navLinks">
      <li><a href="#sekilas">Sekilas</a></li>
      <li><a href="#budidaya">Budidaya</a></li>
      <li><a href="#pakan">Pakan</a></li>
      <li><a href="#kualitas">Kualitas</a></li>
      <li><a href="#simpan">Simpan</a></li>
      <li><a href="#mitos">Mitos</a></li>
      <li><a href="#usaha">Usaha</a></li>
      <li><a href="#referensi">Referensi</a></li>
      <li><a href="#kontak">Kontak</a></li>
    </ul>
    <div class="nav-right">
      <button class="theme-btn" id="themeBtn" aria-label="Aktifkan mode gelap" aria-pressed="false" title="Mode gelap">&#9681;</button>
    </div>
  </div>
</nav>

<main id="main-content">
<header class="hero" id="top">
  <div class="wrap">
    <div class="hero-grid">
      <div>
        <div class="sp-jp eyebrow">Coturnix japonica</div>
        <div class="sp-bt eyebrow">Excalfactoria chinensis</div>
        <h1>Kecil. Cepat.<br><em>Produktif.</em> <span class="dim">&mdash; puyuh.</span></h1>
        <div class="sp-pick">
          <label for="spSel">Jenis puyuh</label>
          <select id="spSel">
            <option value="jp">Puyuh Jepang (C. japonica)</option>
            <option value="bt">Puyuh Batu (E. chinensis)</option>
          </select>
        </div>
        <a class="hero-cta" href="#sekilas">Mulai membaca <span aria-hidden="true">&darr;</span></a>
      </div>
    </div>
  </div>
</header>

<div class="ticker" role="region" tabindex="0" aria-label="Sorotan informasi; arahkan pointer atau fokus untuk menjeda animasi">
  <div class="sp-jp ticker-track" aria-hidden="true">
    <span>Coturnix japonica <i class="dot">&#9679;</i></span><span>Budidaya lahan sempit <i class="dot">&#9679;</i></span><span>Telur tetas 17 hari <i class="dot">&#9679;</i></span><span>Pakan 20&ndash;30 g/ekor/hari <i class="dot">&#9679;</i></span><span>Mulai bertelur &plusmn;6 minggu <i class="dot">&#9679;</i></span><span>Ransum 20% protein <i class="dot">&#9679;</i></span>
    <span>Coturnix japonica <i class="dot">&#9679;</i></span><span>Budidaya lahan sempit <i class="dot">&#9679;</i></span><span>Telur tetas 17 hari <i class="dot">&#9679;</i></span><span>Pakan 20&ndash;30 g/ekor/hari <i class="dot">&#9679;</i></span><span>Mulai bertelur &plusmn;6 minggu <i class="dot">&#9679;</i></span><span>Ransum 20% protein <i class="dot">&#9679;</i></span>
  </div>
  <div class="sp-bt ticker-track" aria-hidden="true">
    <span>Excalfactoria chinensis <i class="dot">&#9679;</i></span><span>Puyuh terkecil di dunia <i class="dot">&#9679;</i></span><span>Monogami <i class="dot">&#9679;</i></span><span>Telur 5&ndash;13 butir per sarang <i class="dot">&#9679;</i></span><span>Inkubasi 16&ndash;21 hari <i class="dot">&#9679;</i></span><span>Status Least Concern (IUCN) <i class="dot">&#9679;</i></span>
    <span>Excalfactoria chinensis <i class="dot">&#9679;</i></span><span>Puyuh terkecil di dunia <i class="dot">&#9679;</i></span><span>Monogami <i class="dot">&#9679;</i></span><span>Telur 5&ndash;13 butir per sarang <i class="dot">&#9679;</i></span><span>Inkubasi 16&ndash;21 hari <i class="dot">&#9679;</i></span><span>Status Least Concern (IUCN) <i class="dot">&#9679;</i></span>
  </div>
</div>

<section id="sekilas" class="s-white">
  <div class="wrap">
    <div class="sec-head reveal">
      <div class="sec-num"><span class="box">S.01</span> Sekilas</div>
      <div>
        <h2>Unggas kecil dengan <em>catatan besar</em>.</h2>
        <p class="sp-jp lede">Puyuh Jepang (Coturnix japonica) berasal dari Asia Timur dan kini diternakkan di hampir seluruh dunia, terutama untuk telurnya yang berbintik khas.</p>
        <p class="sp-bt lede">Puyuh Batu (Excalfactoria chinensis) adalah puyuh terkecil di dunia, tersebar dari Cina selatan sampai Australia timur. Di Indonesia dikenal sebagai puyuh batu atau king quail.</p>
      </div>
    </div>
    <div class="sp-jp">
    <div class="about-grid">
      <div class="about-copy reveal">
        <p>Keunggulan utamanya soal waktu: mulai bertelur jauh lebih cepat dari ayam, dengan pakan yang sedikit. Betina dewasa hanya sekitar 140 g tapi bisa bertelur hampir tiap hari di puncak produksi.</p>
        <p>Tubuh mungil, cocok untuk lahan sempit sampai kandang bertingkat. Satu butir telur setara 8% bobot tubuh induk; ayam hanya 3% (Bagh dkk., 2016).</p>
        <p>Angka patokan dari jurnal: mulai bertelur 6 minggu, produksi 250&ndash;300 butir/tahun (Animals, 2025). Ransum terbaik: 20% protein kasar, 3.000 kkal/kg energi metabolis (Agboola dkk., 2017), kalsium 2,5% untuk kerabang (Sultana dkk., 2007).</p>
        <p>Gizinya juga menarik: lemak telur didominasi asam lemak tak jenuh, asam oleat sekitar 40% dari total lemak (Czerwonka &amp; Białek, 2024). Kecil, tapi padat gizi.</p>
      </div>
      <div class="reveal d1">
        <div class="fact-table">
          <div class="fact-row"><b>&plusmn;6 minggu</b><span class="k">mulai bertelur</span></div>
          <div class="fact-row"><b>250&ndash;300 butir</b><span class="k">produksi / tahun</span></div>
          <div class="fact-row"><b>8&ndash;12 g</b><span class="k">bobot per telur</span></div>
          <div class="fact-row"><b>20&ndash;30 g</b><span class="k">pakan / ekor / hari</span></div>
          <div class="fact-row"><b>17 hari</b><span class="k">masa inkubasi</span></div>
          <div class="fact-row"><b>12&ndash;14 bulan</b><span class="k">masa produktif</span></div>
        </div>
        <p class="fact-src">* Angka umum dari literatur; hasil aktual tergantung bibit, pakan, dan manajemen kandang.</p>
      </div>
    </div>
    </div>
    <div class="sp-bt">
    <div class="about-grid">
      <div class="about-copy reveal">
        <p>Puyuh batu (Excalfactoria chinensis, sin. Synoicus chinensis) adalah anggota <b>ordo Galliformes terkecil di dunia</b> (McGowan &amp; Madge, 2010). Panjang tubuh 12&ndash;15 cm, lebar sayap &plusmn;25 cm, bobot 20&ndash;57 g; betina sedikit lebih besar dari jantan (Pappas, ADW).</p>
        <p>Jantan sangat mencolok: dada biru-abu, tenggorokan hitam dengan garis putih, tubuh bawah merah tua. Betina cokelat kemerahan polos &mdash; lebih samar. Di Indonesia, subspesies <i>palmeri</i> ditemukan di Sumatra-Jawa, dan <i>lineatus</i> di Sulawesi, Nusa Tenggara, &amp; Kalimantan.</p>
        <p>Tidak seperti puyuh Jepang yang dibudidayakan untuk telur, puyuh batu lebih dikenal sebagai <b>burung hias dan model penelitian</b>. Monogami dengan ikatan pasangan kuat (Adkins-Regan dkk., 2016). Status IUCN: <b>Least Concern</b> (BirdLife International, 2016).</p>
        <p>Sebagai hewan laboratorium, Excalfactoria chinensis sudah digunakan sejak 1990-an (Tsudzuki, 1994). Ukurannya yang kecil, siklus cepat, dan adaptasi mudah membuatnya ideal untuk studi genetika dan reproduksi.</p>
      </div>
      <div class="reveal d1">
        <div class="fact-table">
          <div class="fact-row"><b>12&ndash;15 cm</b><span class="k">panjang tubuh</span></div>
          <div class="fact-row"><b>20&ndash;57 g</b><span class="k">bobot dewasa</span></div>
          <div class="fact-row"><b>5&ndash;13 butir</b><span class="k">clutch / sarang</span></div>
          <div class="fact-row"><b>16&ndash;21 hari</b><span class="k">masa inkubasi</span></div>
          <div class="fact-row"><b>Monogami</b><span class="k">sistem kawin</span></div>
          <div class="fact-row"><b>3&ndash;6 tahun</b><span class="k">umur penangkaran</span></div>
        </div>
        <p class="fact-src">* Sumber: McGowan &amp; Madge (2010); Pappas (ADW); Adkins-Regan dkk. (2016); Tsudzuki (1994); BirdLife International (2016).</p>
      </div>
    </div>
    </div>
  </div>
</section>

<section id="budidaya" class="s-paper">
  <div class="wrap">
    <div class="sec-head reveal">
      <div class="sec-num"><span class="box">S.02</span> Budidaya</div>
      <div>
        <h2>Empat langkah, dari bibit sampai <em>telur pertama</em>.</h2>
        <p class="sp-jp lede">Alur budidaya puyuh petelur yang umum: siapkan bibit yang sehat, kandang yang nyaman, ransum yang sesuai, lalu panen telurnya.</p>
        <p class="sp-bt lede">Budidaya puyuh batu lebih dekat ke pemeliharaan burung hias: kandang yang aman di tanah, pasangan yang cocok, pakan yang tepat, dan kesabaran menunggu telur menetas.</p>
      </div>
    </div>
    <div class="sp-jp">
    <div class="steps reveal">
      <div class="step">
        <span class="tag">bibit</span>
        <span class="no">01</span>
        <h3>Pilih DOQ yang sehat</h3>
        <p>Mulai dari anak puyuh (<em>day old quail</em>) pembibitan terpercaya. Ciri sehat: lincah, bulu kering, dubur bersih. Menetaskan sendiri? Setel 37&ndash;38&deg;C dengan kelembapan &plusmn;55&ndash;60%; di bawah 35&deg;C hampir pasti gagal (Romao dkk., 2009).</p>
      </div>
      <div class="step">
        <span class="tag">kandang</span>
        <span class="no">02</span>
        <h3>Siapkan kandang nyaman</h3>
        <p>Kandang baterai atau koloni dengan ventilasi baik, suhu 25&ndash;30&deg;C untuk dewasa. Luas ideal <b>150&ndash;200 cm&sup2; per ekor</b>; kepadatan berlebih menurunkan produksi dan daya tahan tubuh (El-Tarabany, 2016).</p>
      </div>
      <div class="step">
        <span class="tag">pakan</span>
        <span class="no">03</span>
        <h3>Ransum &amp; air bersih</h3>
        <p>Ransum petelur: <b>&plusmn;20% protein</b>, energi <b>3.000 kkal/kg</b>, kalsium <b>2,5%</b> untuk kerabang (Agboola dkk., 2017; Sultana dkk., 2007). Air bersih harus selalu tersedia.</p>
      </div>
      <div class="step">
        <span class="tag">panen</span>
        <span class="no">04</span>
        <h3>Panen telur rutin</h3>
        <p>Telur mulai turun saat umur &plusmn;6 minggu. Panen pagi dan sore, simpan di tempat sejuk dengan posisi tumpul di atas. Telur cepat didinginkan bertahan lebih lama.</p>
      </div>
    </div>
    </div>
    <div class="sp-bt">
    <div class="steps reveal">
      <div class="step">
        <span class="tag">kandang</span>
        <span class="no">01</span>
        <h3>Kandang aviary di tanah</h3>
        <p>Puyuh batu hidup <b>di permukaan tanah</b>, bukan bertengger. Kandang aviary tertutup dengan lantai rumput atau alas halus paling cocok; mata kawat rapat karena kakinya kecil. Sediakan rumpun rumput atau tumpukan dedaunan sebagai tempat bersembunyi dan bersarang (Pappas, 1996).</p>
      </div>
      <div class="step">
        <span class="tag">pasangan</span>
        <span class="no">02</span>
        <h3>Pasangkan dengan benar</h3>
        <p>Spesies ini <b>monogami</b> dengan ikatan pasangan kuat (Adkins-Regan dkk., 2016). Pelihara berpasangan atau satu jantan dengan beberapa betina; dua jantan dalam satu kandang bisa bertarung memperebutkan betina (McGowan &amp; Madge, 2010).</p>
      </div>
      <div class="step">
        <span class="tag">pakan</span>
        <span class="no">03</span>
        <h3>Pakan &amp; air bersih</h3>
        <p>Berikan pakan puyuh/biji-bijian halus berkualitas plus sumber protein hewani kecil (serangga, ulat hongkong). Dengan pakan yang tepat, betina bisa bertelur <b>1 butir per hari</b> selama musim (McGowan &amp; Madge, 2010). Air bersih selalu tersedia.</p>
      </div>
      <div class="step">
        <span class="tag">penetasan</span>
        <span class="no">04</span>
        <h3>Telur &amp; penetasan</h3>
        <p>Clutch 5&ndash;13 butir, dierami betina atau ditetaskan dengan inkubator; studi penangkaran melaporkan masa inkubasi <b>16&ndash;21 hari</b> (&Uuml;&ccedil;tepe, 2025). Anak puyuh dirawat induk sampai &plusmn;4 minggu, lalu bisa dipisah ke kandang sendiri.</p>
      </div>
    </div>
    </div>
  </div>
</section>

<section id="pakan" class="s-white">
  <div class="wrap">
    <div class="sec-head reveal">
      <div class="sec-num"><span class="box">S.03</span> Pakan &amp; nutrisi</div>
      <div>
        <h2 class="sp-jp">Ransum yang <em>pas</em>.</h2>
        <h2 class="sp-bt">Tubuh mini, <em>ransum spesifik</em>.</h2>
        <p class="sp-jp lede">Lebih dari separuh biaya beternak puyuh ada di pakan. Memberi ransum yang pas, tidak kurang dan tidak berlebih, adalah kunci produksi yang efisien.</p>
        <p class="sp-bt lede">Puyuh batu lebih kecil dari puyuh Jepang. Kebutuhan pakannya tidak boleh disalin mentah dari ransum puyuh petelur komersial.</p>
      </div>
    </div>
    <div class="sp-jp">
    <div class="tbl reveal" role="region" aria-label="Tabel kebutuhan pakan puyuh" tabindex="0">
      <table>
        <caption class="sr-only">Kebutuhan pakan puyuh petelur dan sumber ilmiahnya</caption>
        <thead>
          <tr><th scope="col">Komponen</th><th scope="col">Kebutuhan puyuh petelur</th><th scope="col">Sumber</th></tr>
        </thead>
        <tbody>
          <tr><th scope="row"><b>Protein kasar</b></th><td>&plusmn;20% (kisaran yang diuji 18&ndash;24%)</td><td>Agboola dkk., 2017</td></tr>
          <tr><th scope="row"><b>Energi metabolis</b></th><td>&plusmn;3.000 kkal/kg</td><td>Agboola dkk., 2017</td></tr>
          <tr><th scope="row"><b>Kalsium</b></th><td>&plusmn;2,5%</td><td>Sultana dkk., 2007</td></tr>
          <tr><th scope="row"><b>Konsumsi pakan</b></th><td>20&ndash;35 g per ekor per hari</td><td>Agboola dkk., 2017</td></tr>
          <tr><th scope="row"><b>Batas bawah protein</b></th><td>16% &mdash; di bawah ini produksi merosot</td><td>J. Poult. Sci., 2005</td></tr>
        </tbody>
      </table>
    </div>
    <p class="tbl-note reveal">* Nilai dari percobaan pemberian pakan pada puyuh Jepang; kebutuhan aktual bisa bergeser tergantung galur, umur, dan suhu kandang.</p>
    <div class="two-col reveal">
      <div class="copy">
        <p>Protein <b>20%</b> dengan energi <b>3.000 kkal/kg</b> memberi produksi dan kualitas telur terbaik (Agboola dkk., 2017). Protein 16% terbukti menekan produksi (J. Poult. Sci., 2005).</p>
        <p>Ransum <b>240 g protein/kg</b> dengan keseimbangan elektrolit tertentu menjaga putih telur tetap awet selama penyimpanan (Vieira dkk., 2015). Komposisi ransum ikut menentukan umur simpan telur.</p>
      </div>
      <div class="copy">
        <p><b>Air lebih penting dari yang dikira.</b> Puyuh makan 20&ndash;35 g pakan sehari (Agboola dkk., 2017) tapi minum lebih banyak. Air terputus sebentar saja langsung terlihat dari produksinya.</p>
        <p>Perhatikan juga bahan baku: jagung dan bungkil kedelai yang lembap bisa berjamur &mdash; pakan berjamur berbahaya untuk puyuh. Simpan pakan di tempat kering.</p>
      </div>
    </div>
    </div>
    <div class="sp-bt">
      <div class="tbl reveal" role="region" aria-label="Tabel ransum puyuh batu" tabindex="0">
        <table>
          <caption class="sr-only">Ransum puyuh batu berdasarkan penelitian spesifik spesies</caption>
          <thead>
            <tr><th scope="col">Fase / praktik</th><th scope="col">Angka yang diteliti</th><th scope="col">Sumber</th></tr>
          </thead>
          <tbody>
            <tr><th scope="row"><b>Umur 1&ndash;4 minggu</b></th><td>&gt;20,4% protein kasar; 2.750 kkal/kg energi metabolis</td><td>Wei dkk., 2011</td></tr>
            <tr><th scope="row"><b>Anak &amp; juvenil</b></th><td>Ransum komersial puyuh Jepang dengan 24% protein pernah digunakan</td><td>Tsudzuki, 1994</td></tr>
            <tr><th scope="row"><b>Dewasa penelitian</b></th><td>23% protein; 2.900 kkal/kg; kalsium 3,5%</td><td>Cai dkk., 2019</td></tr>
            <tr><th scope="row"><b>Variasi tambahan</b></th><td>Biji kecil, hijauan, larva <i>Tenebrio</i>, vitamin &amp; mineral</td><td>&Uuml;&ccedil;tepe, 2025</td></tr>
            <tr><th scope="row"><b>Air minum</b></th><td>Tersedia bebas sepanjang pemeliharaan</td><td>&Uuml;&ccedil;tepe, 2025</td></tr>
          </tbody>
        </table>
      </div>
      <p class="tbl-note reveal">* Angka di atas berasal dari percobaan puyuh batu, bukan standar ransum nasional. Sesuaikan bentuk pakan dengan paruhnya yang kecil dan pantau kondisi tubuh.</p>
      <div class="two-col reveal">
        <div class="copy">
          <p><b>Fase tumbuh paling jelas datanya.</b> Pada umur 1&ndash;4 minggu, performa baik dicapai dengan protein kasar di atas <b>20,4%</b> dan energi metabolis <b>2.750 kkal/kg</b>. Ransum sangat tinggi sekitar 30% protein tidak diperlukan pada kondisi percobaan tersebut (Wei dkk., 2011).</p>
          <p>Sejumlah koloni penelitian memakai <b>starter puyuh sampai umur 4 minggu</b>, lalu beralih ke ransum breeder. Artinya, biji atau serangga saja bukan pengganti ransum lengkap.</p>
        </div>
        <div class="copy">
          <p><b>Angka dewasa adalah contoh protokol.</b> Cai dkk. (2019) memakai 23% protein, 2.900 kkal/kg, dan 3,5% kalsium. Nilai ini berguna sebagai rujukan penelitian, bukan jaminan produksi untuk semua kandang.</p>
          <p>Literatur juga mencatat biji kecil, hijauan, dan larva <i>Tenebrio</i> sebagai variasi tambahan. Dasarnya tetap pakan lengkap, mineral yang cukup, serta air bersih tersedia terus (&Uuml;&ccedil;tepe, 2025).</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="kualitas" class="s-white">
  <div class="wrap">
    <div class="sec-head reveal">
      <div class="sec-num"><span class="box">S.04</span> Kualitas telur</div>
      <div>
        <h2 class="sp-jp">Yang bikin telur <em>layak jual</em>.</h2>
        <h2 class="sp-bt">Telur kecil, <em>siklus besar</em>.</h2>
        <p class="sp-jp lede">Kualitas telur adalah penentu harga di pasar. Ada dua sisi yang dinilai: bagian luar (bobot, bentuk, kerabang) dan bagian dalam (putih telur, kuning telur, kesegaran).</p>
        <p class="sp-bt lede">Puyuh batu tidak diternakkan untuk telur komersial &mdash; telurnya lebih dipakai untuk tetas dan seleksi. Angka ukuran dan siklusnya tetap penting untuk dikenali.</p>
      </div>
    </div>
    <div class="sp-jp">
    <div class="quality-grid">
      <div class="quality-art reveal">
        <picture><source srcset="telur-puyuh.webp" type="image/webp"><img src="telur-puyuh.png" alt="Telur puyuh berbintik khas" width="700" height="934" loading="lazy" decoding="async"></picture>
      </div>
      <div class="reveal d1">
        <div class="q-params">
          <div class="q-row"><span class="v">10&ndash;12 g <small>// bobot</small></span><span class="k">BB</span></div>
          <div class="q-row"><span class="v">70&ndash;80% <small>// shape index</small></span><span class="k">SI</span></div>
          <div class="q-row"><span class="v">0,20&ndash;0,30 mm <small>// kerabang</small></span><span class="k">TK</span></div>
          <div class="q-row"><span class="v">&gt;72 <small>// haugh unit</small></span><span class="k">HU</span></div>
          <div class="q-row"><span class="v">42&ndash;48% <small>// yolk index</small></span><span class="k">YI</span></div>
        </div>
        <p class="q-note">* Angka dari pengukuran langsung pada tiga varietas puyuh Jepang (Bagh dkk., 2016) dan rentang yang dilaporkan literatur (Altan dkk.; KVFD, 2010).</p>
      </div>
    </div>
    <div class="two-col">
      <div class="copy reveal">
        <p>Kualitas tidak datang sendiri: kepadatan longgar (<b>200 cm&sup2; per ekor</b>) menjaga Haugh unit dan yolk index tetap tinggi (El-Tarabany, 2016); protein cukup dan kalsium <b>2,5%</b> menjaga bobot telur dan kerabang (Agboola dkk., 2017; Sultana dkk., 2007).</p>
        <p>Kesegaran menurun seiring waktu: semakin lama disimpan, semakin rendah Haugh unit-nya. Kualitas terbaik diukur dari telur yang baru dipanen.</p>
      </div>
      <div class="copy reveal d1">
        <p><b>Haugh unit</b> adalah standar kesegaran, dihitung dari tinggi putih telur kental dibanding bobot telur. Di atas 72 = baik (grade AA); telur segar puyuh umumnya 85&ndash;95 (Bagh dkk., 2016).</p>
        <p><b>Yolk index</b> mengukur kekentalan kuning telur: bulat dan tegak berarti segar, melebar pipih berarti sudah lama. Dua-duanya tolok ukur paling umum di penelitian telur.</p>
      </div>
    </div>
    </div>
    <div class="sp-bt">
    <div class="quality-grid">
      <div class="quality-art reveal">
        <picture><source srcset="telur-puyuh.webp" type="image/webp"><img src="telur-puyuh.png" alt="Telur puyuh berbintik khas" width="700" height="934" loading="lazy" decoding="async"></picture>
      </div>
      <div class="reveal d1">
        <div class="q-params">
          <div class="q-row"><span class="v">&plusmn;25 &times; 19 mm <small>// ukuran telur</small></span><span class="k">TELUR</span></div>
          <div class="q-row"><span class="v">5&ndash;13 butir <small>// clutch</small></span><span class="k">SARANG</span></div>
          <div class="q-row"><span class="v">16&ndash;21 hari <small>// inkubasi</small></span><span class="k">TETAS</span></div>
          <div class="q-row"><span class="v">1 butir/hari <small>// saat musim</small></span><span class="k">PRODUKSI</span></div>
          <div class="q-row"><span class="v">&plusmn;4 minggu <small>// rawat anak</small></span><span class="k">INDUK</span></div>
        </div>
        <p class="q-note">* Ukuran telur &plusmn;25&times;19 mm, warna krem sampai cokelat zaitun dengan bintik hitam halus (McGowan &amp; Madge, 2010).</p>
      </div>
    </div>
    <div class="two-col">
      <div class="copy reveal">
        <p>Telur puyuh batu <b>kecil mungil</b>: sekitar <b>25&times;19 mm</b>, warna krem kecokelatan sampai cokelat zaitun yang dihiasi bintik hitam halus (McGowan &amp; Madge, 2010). Karena bukan komoditas telur konsumsi, telur ini hampir selalu untuk <b>penetasan dan seleksi bibit</b>.</p>
        <p>Satu betina bertelur <b>1 butir per hari</b> selama musim bila pakan dan kondisi kandang tepat (McGowan &amp; Madge, 2010). Setelah clutch terkumpul, betina baru mengerami.</p>
      </div>
      <div class="copy reveal d1">
        <p><b>Masa inkubasi 16&ndash;21 hari</b> pada berbagai protokol penangkaran (&Uuml;&ccedil;tepe, 2025). Betina mengerami sendiri atau telur dipindah ke inkubator bila ingin menetaskan lebih banyak. Anak puyuh dirawat induk hingga <b>&plusmn;4 minggu</b> sebelum bisa dipisah.</p>
        <p>Karena sistemnya <b>monogami</b> (Adkins-Regan dkk., 2016), pengelolaan reproduksi lebih tenang dan terencana dibanding puyuh petelur yang dipelihara massal.</p>
      </div>
    </div>
    </div>
  </div>
</section>

<section id="simpan" class="s-paper">
  <div class="wrap">
    <div class="sec-head reveal">
      <div class="sec-num"><span class="box">S.05</span> Penyimpanan</div>
      <div>
        <h2 class="sp-jp">Telur segar, <em>caranya disimpan</em>.</h2>
        <h2 class="sp-bt">Simpan singkat, <em>daya tetas dijaga</em>.</h2>
        <p class="sp-jp lede">Telur puyuh cepat kehilangan kesegaran di suhu ruang. Kuncinya: petik rutin, dinginkan cepat, dan simpan dengan benar.</p>
        <p class="sp-bt lede">Telur puyuh batu umumnya disimpan untuk ditetaskan. Ukurannya bukan umur konsumsi, melainkan berapa lama embrio tetap mampu berkembang.</p>
      </div>
    </div>
    <div class="sp-jp">
    <div class="simpan-grid">
      <div class="copy reveal">
        <p>Di suhu ruang (&plusmn;27&deg;C), kualitas menurun drastis dalam 30 hari; telur mulai <b>mengambang di air sejak hari ke-15</b> karena isi menyusut (Acta Scientiarum, 2023).</p>
        <p>Di lemari es jauh lebih lama: Haugh unit tetap di atas 72 setelah <b>120 hari</b> di 4&deg;C (J. Appl. Poult. Res., 2022), bahkan sampai 16 minggu (Kumb&aacute;r dkk., 2015). Suhu ideal 10&ndash;15&deg;C, kelembapan 70&ndash;80% (Silva dkk., 2020).</p>
        <p>Kesegaran tidak terlihat dari kulitnya: telur bersih belum tentu segar, telur kotor belum tentu buruk. Kutikula adalah pelindung alami, jangan dihilangkan dengan mencuci.</p>
        <p>Prinsipnya satu: <b>panen rutin, dinginkan cepat</b>. Semakin pendek waktu di suhu ruang, semakin lama umur simpannya.</p>
      </div>
      <div class="tips-block reveal d1">
        <h3 class="tips-title">Lima kebiasaan simpan yang benar</h3>
        <ul class="tips">
          <li><span class="no">1</span><span>Petik telur <b>pagi dan sore</b>, dua kali sehari &mdash; telur yang lama menginap di kandang lebih cepat kotor dan retak (Sultana dkk., 2007).</span></li>
          <li><span class="no">2</span><span>Segera masukkan ke <b>lemari es</b>; telur yang dibiarkan di suhu ruang kualitasnya langsung tertinggal dari yang didinginkan (Boletim Ind&uacute;stria Animal, 2020).</span></li>
          <li><span class="no">3</span><span>Simpan dengan <b>ujung tumpul di atas</b> supaya kantong udara tetap di tempatnya dan kuning telur tidak menempel di kerabang.</span></li>
          <li><span class="no">4</span><span>Jangan <b>cuci telur</b> sebelum disimpan &mdash; lapisan pelindung (kutikula) di kerabang hilang kalau dicuci, telur jadi cepat basi.</span></li>
          <li><span class="no">5</span><span>Gunakan <b>tes rendam</b>: telur yang tenggelam berarti segar, yang mengambang sudah lama &mdash; indikatornya terbukti dari penelitian penyimpanan (Acta Scientiarum, 2023).</span></li>
        </ul>
      </div>
    </div>
    </div>
    <div class="sp-bt">
      <div class="tbl reveal" role="region" aria-label="Tabel penyimpanan dan penetasan telur puyuh batu" tabindex="0">
        <table>
          <caption class="sr-only">Kondisi penyimpanan dan inkubasi telur puyuh batu dalam penelitian</caption>
          <thead>
            <tr><th scope="col">Tahap</th><th scope="col">Kondisi penelitian</th><th scope="col">Sumber</th></tr>
          </thead>
          <tbody>
            <tr><th scope="row"><b>Simpan singkat</b></th><td>12&ndash;14&deg;C, maksimum 7 hari</td><td>Ono dkk., 2005</td></tr>
            <tr><th scope="row"><b>Studi perkembangan</b></th><td>15&deg;C, maksimum 5 hari</td><td>Nakamura dkk., 2019</td></tr>
            <tr><th scope="row"><b>Uji suhu simpan</b></th><td>16 atau 21&deg;C; RH 65&ndash;75%; 3, 7, atau 14 hari</td><td>Cai dkk., 2019</td></tr>
            <tr><th scope="row"><b>Inkubasi</b></th><td>37,5&deg;C; RH 55&ndash;65%; menetas sekitar 16&ndash;17 hari</td><td>Cai dkk., 2019</td></tr>
            <tr><th scope="row"><b>Pemutaran</b></th><td>45&deg; tiap jam selama 14 hari pertama</td><td>Cai dkk., 2019</td></tr>
          </tbody>
        </table>
      </div>
      <p class="tbl-note reveal">* Ini protokol telur tetas dalam penelitian puyuh batu. Jangan memakai angka umur simpan telur konsumsi Puyuh Jepang untuk menilai daya tetasnya.</p>
      <div class="simpan-grid">
        <div class="copy reveal">
          <p><b>Suhu dan durasi bekerja bersama.</b> Dalam percobaan Cai dkk. (2019), penyimpanan pada <b>16&deg;C</b> menghasilkan daya tetas lebih tinggi daripada 21&deg;C. Penyimpanan yang makin lama menurunkan daya tetas dan menaikkan kematian embrio.</p>
          <p>Penelitian lain menyimpan telur hanya <b>5&ndash;7 hari</b> pada 12&ndash;15&deg;C sebelum inkubasi. Rentang ini menunjukkan prinsip yang konsisten: sejuk, singkat, dan tercatat; bukan disimpan berbulan-bulan seperti telur konsumsi.</p>
          <p>Protokol inkubasi berbeda antar studi, tetapi banyak penelitian berada dekat <b>37,5&deg;C</b>. Cai dkk. memakai RH 55&ndash;65% dan pemutaran 45&deg; tiap jam selama 14 hari pertama.</p>
        </div>
        <div class="tips-block reveal d1">
          <h3 class="tips-title">Empat catatan sebelum telur masuk mesin</h3>
          <ul class="tips">
            <li><span class="no">1</span><span>Tulis <b>tanggal bertelur dan pasangan induk</b>; umur telur tidak boleh ditebak.</span></li>
            <li><span class="no">2</span><span>Pilih satu protokol suhu simpan yang terbukti, lalu jaga agar <b>tidak naik-turun</b>.</span></li>
            <li><span class="no">3</span><span>Batasi penyimpanan; data spesies ini menunjukkan <b>durasi panjang menekan daya tetas</b> (Cai dkk., 2019).</span></li>
            <li><span class="no">4</span><span>Catat fertilitas, kematian embrio, dan hasil tetas per pasangan agar masalah induk tidak tertukar dengan masalah mesin.</span></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="mitos" class="s-white">
  <div class="wrap">
    <div class="sec-head reveal">
      <div class="sec-num"><span class="box">S.06</span> Mitos &amp; fakta</div>
      <div>
        <h2>Pernah dengar yang <em>ini?</em></h2>
        <p class="sp-jp lede">Beberapa anggapan soal puyuh yang sering beredar di pasar dan grup ternak, dicek dengan data dari jurnal.</p>
        <p class="sp-bt lede">Anggapan soal puyuh batu yang sering tertukar dengan puyuh petelur, dicek dengan literatur ilmiah.</p>
      </div>
    </div>
    <div class="sp-jp myth reveal">
      <div class="myth-row">
        <div>
          <span class="myth-label"><span class="x">&#10005;</span>Mitos</span>
          <p>Telur puyuh bikin kolesterol naik, lebih baik dihindari.</p>
        </div>
        <div class="fact">
          <span class="fact-label"><span class="chk">&#10003;</span>Fakta</span>
          <p>Lemak telur puyuh didominasi <b>asam lemak tak jenuh</b> &mdash; asam oleat sekitar 40% dari total lemak. Bukan bebas kolesterol, tapi tidak perlu dihindari berlebihan; porsi dan cara masak tetap penentu.</p>
          <span class="src">Czerwonka &amp; Białek, Foods 13:1571, 2024</span>
        </div>
      </div>
      <div class="myth-row">
        <div>
          <span class="myth-label"><span class="x">&#10005;</span>Mitos</span>
          <p>Puyuh gampang stres dan gampang mati, ribet dipelihara.</p>
        </div>
        <div class="fact">
          <span class="fact-label"><span class="chk">&#10003;</span>Fakta</span>
          <p>Puyuh <b>tahan penyakit</b>, pakan sedikit, ruang kecil (Animals, 2022). Stres yang menurunkan produksi biasanya dari <b>kepadatan kandang berlebih</b> &mdash; beri sekitar 200 cm&sup2; per ekor (El-Tarabany, 2016).</p>
          <span class="src">Animals 12(20):2811, 2022; J. Anim. Physiol. Anim. Nutr., 2016</span>
        </div>
      </div>
      <div class="myth-row">
        <div>
          <span class="myth-label"><span class="x">&#10005;</span>Mitos</span>
          <p>Telur harus dicuci dulu biar bersih sebelum disimpan.</p>
        </div>
        <div class="fact">
          <span class="fact-label"><span class="chk">&#10003;</span>Fakta</span>
          <p>Mencuci menghilangkan <b>kutikula</b>, pelindung kerabang. Telur kotor cukup <b>dilap kering</b>, dan kesegaran dijaga dengan <b>pendinginan</b>, bukan pencucian (Acta Scientiarum, 2023; Boletim de Ind&uacute;stria Animal, 2020).</p>
          <span class="src">Acta Sci. Anim. Sci. 45, 2023; Boletim de Ind&uacute;stria Animal 77, 2020</span>
        </div>
      </div>
      <div class="myth-row">
        <div>
          <span class="myth-label"><span class="x">&#10005;</span>Mitos</span>
          <p>Beternak puyuh butuh lahan luas seperti kandang ayam.</p>
        </div>
        <div class="fact">
          <span class="fact-label"><span class="chk">&#10003;</span>Fakta</span>
          <p>Sebaliknya: puyuh primadona ternak <b>lahan sempit</b>, bisa di kandang bertingkat. Satu butir telur = <b>8% bobot tubuh</b> induk vs ayam 3% (Bagh dkk., 2016; Animals, 2022).</p>
          <span class="src">Bagh dkk., 2016; Animals 12(20):2811, 2022</span>
        </div>
      </div>
    </div>
    <div class="sp-bt myth reveal">
      <div class="myth-row">
        <div>
          <span class="myth-label"><span class="x">&#10005;</span>Mitos</span>
          <p>Puyuh batu itu cuma nama lain dari puyuh petelur.</p>
        </div>
        <div class="fact">
          <span class="fact-label"><span class="chk">&#10003;</span>Fakta</span>
          <p>Dua spesies berbeda. Puyuh Jepang (<i>Coturnix japonica</i>) dibudidayakan untuk telur; puyuh batu (<i>Excalfactoria chinensis</i>) adalah <b>puyuh terkecil di dunia</b> &mdash; 12&ndash;15 cm, 20&ndash;57 g &mdash; dan lebih dikenal sebagai burung hias serta hewan penelitian (McGowan &amp; Madge, 2010; Tsudzuki, 1994).</p>
          <span class="src">McGowan &amp; Madge, 2010; Tsudzuki, Poult. Sci. 73:763&ndash;768, 1994</span>
        </div>
      </div>
      <div class="myth-row">
        <div>
          <span class="myth-label"><span class="x">&#10005;</span>Mitos</span>
          <p>Puyuh batu gampang mati, tidak kuat dipelihara.</p>
        </div>
        <div class="fact">
          <span class="fact-label"><span class="chk">&#10003;</span>Fakta</span>
          <p>Cukup kuat di penangkaran dengan kandang yang sesuai: umur umum <b>3&ndash;6 tahun</b>, bahkan tercatat sampai 13 tahun. Kuncinya kandang di tanah, bukan kawat halus yang melukai kaki kecilnya (Pappas, ADW; McGowan &amp; Madge, 2010).</p>
          <span class="src">Pappas, Animal Diversity Web; McGowan &amp; Madge, 2010</span>
        </div>
      </div>
      <div class="myth-row">
        <div>
          <span class="myth-label"><span class="x">&#10005;</span>Mitos</span>
          <p>Telur puyuh batu bisa jadi ladang bisnis seperti telur puyuh petelur.</p>
        </div>
        <div class="fact">
          <span class="fact-label"><span class="chk">&#10003;</span>Fakta</span>
          <p>Koloni penelitian terkendali pernah mencapai produksi <b>60&ndash;80%</b> dan sekitar <b>250 telur/tahun</b>. Namun, Puyuh Batu tidak diseleksi sebagai petelur komersial dan belum memiliki data kelayakan usaha Indonesia; potensi biologis tidak otomatis berarti bisnis telur massal.</p>
          <span class="src">Tsudzuki, 1994; Cai dkk., 2019; &Uuml;&ccedil;tepe, 2025</span>
        </div>
      </div>
      <div class="myth-row">
        <div>
          <span class="myth-label"><span class="x">&#10005;</span>Mitos</span>
          <p>Semua puyuh poligami, jantan bisa dikawinkan dengan banyak betina.</p>
        </div>
        <div class="fact">
          <span class="fact-label"><span class="chk">&#10003;</span>Fakta</span>
          <p>Puyuh batu <b>monogami</b> dengan ikatan pasangan yang kuat (Adkins-Regan dkk., 2016). Jantan dan betina saling memilih; dua jantan dalam satu kandang justru berisiko bertarung memperebutkan betina.</p>
          <span class="src">Adkins-Regan dkk., PLoS ONE 11(6):e0155877, 2016</span>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="usaha" class="s-paper">
  <div class="wrap">
    <div class="sec-head reveal">
      <div class="sec-num"><span class="box">S.07</span> Analisis usaha</div>
      <div>
        <h2 class="sp-jp">Telur laku, tapi <em>untungnya</em> di mana?</h2>
        <h2 class="sp-bt">Bukan petelur massal, <em>pasarnya khusus</em>.</h2>
        <p class="sp-jp lede">Beternak puyuh terkenal cepat balik modal. Tapi di lapangan, untung-rugi ditentukan tiga angka: produksi telur, harga jual, dan biaya pakan. Ketiganya diuji di sejumlah studi kelayakan.</p>
        <p class="sp-bt lede">Nilai Puyuh Batu lebih dekat ke burung hobi, bibit, dan hewan model penelitian. Angka usaha Puyuh Jepang tidak boleh dipakai sebagai proyeksi spesies ini.</p>
      </div>
    </div>
    <div class="sp-jp">
    <div class="tbl reveal" role="region" aria-label="Tabel komponen biaya usaha puyuh" tabindex="0">
      <table>
        <caption class="sr-only">Komponen biaya utama dalam usaha puyuh</caption>
        <thead>
          <tr><th scope="col">Komponen biaya</th><th scope="col">Porsi relatif</th><th scope="col">Catatan</th></tr>
        </thead>
        <tbody>
          <tr><th scope="row"><b>Pakan</b></th><td>Terbesar</td><td>Kenaikan 7% saja sudah bisa membalik usaha dari layak jadi tidak layak (Nisrina dkk., 2022)</td></tr>
          <tr><th scope="row"><b>Bibit (DOC)</b></th><td>Kedua</td><td>Dibeli sekali untuk satu periode produksi &plusmn;12&ndash;14 bulan</td></tr>
          <tr><th scope="row"><b>Kandang &amp; peralatan</b></th><td>Investasi awal</td><td>Dipakai bertahun-tahun; dihitung lewat penyusutan</td></tr>
          <tr><th scope="row"><b>Listrik &amp; penerangan</b></th><td>Kecil</td><td>Pemanas DOQ dan penerangan kandang</td></tr>
          <tr><th scope="row"><b>Obat, vitamin, lain-lain</b></th><td>Kecil</td><td>Termasuk biaya tak terduga</td></tr>
        </tbody>
      </table>
    </div>
    <p class="tbl-note reveal">* Proporsi persisnya beda-beda antar peternak; yang konsisten di studi: pakan selalu komponen terbesar (Ningsih dkk., 2023).</p>
    <div class="two-col reveal">
      <div class="copy">
        <p><b>Pakan adalah medan perangnya.</b> Di Payakumbuh, Sumatera Barat, keluhan peternak hampir selalu sama: harga pakan naik, harga telur relatif rendah &mdash; banyak yang akhirnya beralih ke pakan adukan sendiri agar lebih murah (Ningsih dkk., 2023). Di Pringsewu, Lampung, usaha yang tadinya untung langsung berubah tidak layak kalau biaya pakan naik 7%, produksi turun 4%, atau harga telur turun 4,1% (Nisrina dkk., 2022). Artinya margin usaha puyuh tipis dan sangat peka pada tiga variabel itu.</p>
        <p><b>Angka dari lapangan.</b> Usaha 1.000 ekor di Langsa, Aceh mencatat R/C 2,98 dengan balik modal 3,5 bulan (Dewi dkk., 2023). Peternakan Setu Farm di Bogor: R/C 1,68, BEP harga Rp542/butir, BEP produksi 32.508 butir per periode (Evisari &amp; Kusumawati, 2024). Kelompok Tunas Mekar di Kendari juga dinyatakan layak secara finansial (Ratnasari dkk., 2017). Bedanya ada di manajemen dan skala &mdash; bukan cuma soal punya puyuh.</p>
      </div>
      <div class="copy">
        <p><b>Empat angka yang wajib dikenal.</b> <b>R/C ratio</b> membandingkan penerimaan dengan biaya &mdash; di atas 1 berarti untung, dan studi kasus puyuh berkisar 1,05&ndash;2,98. <b>BEP produksi</b> adalah jumlah butir minimal per periode agar impas; <b>BEP harga</b> adalah harga jual minimal per butir. <b>Payback period</b> mengukur berapa lama modal kembali &mdash; dari 3,5 bulan sampai sekitar 5 tahun tergantung skala dan manajemen.</p>
        <p>Semua ukuran itu dihitung dari catatan sederhana: telur yang dipanen per hari, pakan yang dihabiskan per hari, dan harga jual. Tanpa tiga catatan itu, peternak berjalan buta &mdash; untung atau rugi cuma terasa di akhir bulan, bukan terlihat sejak awal.</p>
      </div>
    </div>
    <div class="tbl reveal" style="margin-top:52px" role="region" aria-label="Tabel ilustrasi usaha 500 ekor puyuh" tabindex="0">
      <table>
        <caption class="sr-only">Ilustrasi kasar penerimaan dan biaya usaha 500 ekor puyuh betina</caption>
        <thead>
          <tr><th scope="col">Contoh kasar &mdash; 500 ekor betina</th><th scope="col">Nilai</th><th scope="col">Dari mana</th></tr>
        </thead>
        <tbody>
          <tr><th scope="row"><b>Produksi harian</b></th><td>&plusmn;400 butir (asumsi produksi 80%)</td><td>Produksi 250&ndash;300 butir/ekor/tahun (Animals, 2025)</td></tr>
          <tr><th scope="row"><b>Penerimaan telur</b></th><td>&plusmn;Rp4,2 juta/bulan</td><td>400 butir &times; Rp350 &times; 30 hari</td></tr>
          <tr><th scope="row"><b>Biaya pakan</b></th><td>&plusmn;Rp3,4 juta/bulan</td><td>25 g/ekor/hari &times; 500 ekor &times; Rp9.000/kg</td></tr>
          <tr><th scope="row"><b>Sisa untuk biaya lain &amp; untung</b></th><td>&plusmn;Rp800 ribu/bulan</td><td>Sebelum listrik, obat, penyusutan, tenaga kerja</td></tr>
        </tbody>
      </table>
    </div>
    <p class="tbl-note reveal">* Angka ini ilustrasi dengan asumsi harga tertentu &mdash; harga telur dan pakan berbeda tiap daerah serta musim. Rumusnya: penerimaan = ekor &times; produksi &times; harga/butir; pakan = ekor &times; konsumsi (kg) &times; harga/kg.</p>
    <div class="tips-block reveal">
      <h3 class="tips-title">Empat kebiasaan yang menjaga margin</h3>
      <ul class="tips">
        <li><span class="no">1</span><span><b>Catat produksi harian.</b> Penurunan produksi 4% saja sudah bisa mengubah usaha dari untung jadi rugi (Nisrina dkk., 2022).</span></li>
        <li><span class="no">2</span><span>Kalau beralih ke <b>pakan adukan</b> untuk hemat, pastikan proteinnya tetap &plusmn;20% &mdash; di bawah itu produksi ikut turun (Agboola dkk., 2017).</span></li>
        <li><span class="no">3</span><span><b>Diversifikasi:</b> telur tetas dan puyuh afkir menambah pemasukan di luar telur konsumsi.</span></li>
        <li><span class="no">4</span><span>Harga telur puyuh <b>musiman</b> &mdash; saat Ramadhan pasokan naik dan harga cenderung turun; siapkan cadangan (Sanjaya dkk., 2018).</span></li>
      </ul>
    </div>
    </div>
    <div class="sp-bt">
      <div class="tbl reveal" role="region" aria-label="Tabel dasar usaha Puyuh Batu" tabindex="0">
        <table>
          <caption class="sr-only">Data biologis dan batas analisis usaha Puyuh Batu</caption>
          <thead>
            <tr><th scope="col">Dasar keputusan</th><th scope="col">Data spesies</th><th scope="col">Makna usaha</th></tr>
          </thead>
          <tbody>
            <tr><th scope="row"><b>Posisi pasar</b></th><td>Burung hobi dan hewan model penelitian</td><td>Bukan pengganti puyuh petelur konsumsi</td></tr>
            <tr><th scope="row"><b>Produksi terkendali</b></th><td>60&ndash;80%; pernah dilaporkan sekitar 250 telur/tahun</td><td>Potensi biologis, bukan jaminan penjualan</td></tr>
            <tr><th scope="row"><b>Generasi</b></th><td>Embrio rata-rata 17 hari; dewasa seksual sekitar 8 minggu</td><td>Siklus bibit relatif cepat</td></tr>
            <tr><th scope="row"><b>Sistem pasangan</b></th><td>Monogami sosial dengan ikatan pasangan</td><td>Catatan produksi harus per pasangan</td></tr>
            <tr><th scope="row"><b>Data finansial</b></th><td>Belum ada R/C, BEP, atau harga baku Indonesia dalam literatur spesifik yang ditinjau</td><td>Wajib uji pasar lokal sebelum menambah skala</td></tr>
          </tbody>
        </table>
      </div>
      <p class="tbl-note reveal">* Produksi 60&ndash;80% dan sekitar 250 telur/tahun berasal dari koloni penelitian terkendali (Tsudzuki, 1994; Cai dkk., 2019), bukan studi laba peternakan Indonesia.</p>
      <div class="two-col reveal">
        <div class="copy">
          <p><b>Produktif secara biologis belum tentu layak secara finansial.</b> Literatur mencatat Puyuh Batu mudah dipelihara di ruang kecil, matang sekitar 8 minggu, serta digunakan sebagai burung hobi dan model penelitian. Namun, studi tersebut tidak memberi harga jual, biaya lokal, R/C ratio, atau BEP (&Uuml;&ccedil;tepe, 2025).</p>
          <p>Karena itu, angka usaha Puyuh Jepang seperti produksi telur konsumsi, harga per butir, dan kandang baterai <b>tidak boleh dipindahkan</b> ke proyeksi Puyuh Batu.</p>
        </div>
        <div class="copy">
          <p><b>Unit hitungnya pasangan, bukan ratusan betina.</b> Catat telur, fertilitas, daya tetas, anak hidup, pakan, listrik inkubator, dan waktu perawatan untuk setiap pasangan. Ramachandran dkk. (2019) juga menunjukkan penyimpanan sperma spesies ini kurang efisien dibanding Puyuh Jepang.</p>
          <p>Rumus minimal: penerimaan bibit atau telur tetas dikurangi biaya induk, kandang aviary, pakan, inkubasi, dan kegagalan tetas. Pasar laboratorium tidak boleh diasumsikan tersedia; buktikan permintaan pembeli lokal lebih dulu.</p>
        </div>
      </div>
      <div class="tips-block reveal">
        <h3 class="tips-title">Empat angka sebelum menambah pasangan</h3>
        <ul class="tips">
          <li><span class="no">1</span><span><b>Permintaan nyata:</b> jumlah calon pembeli, bukan jumlah pengikut atau pertanyaan.</span></li>
          <li><span class="no">2</span><span><b>Fertilitas per pasangan:</b> telur banyak tidak berarti bibit banyak.</span></li>
          <li><span class="no">3</span><span><b>Daya tetas dan anak hidup:</b> hitung hasil sampai siap jual, bukan hanya telur masuk mesin.</span></li>
          <li><span class="no">4</span><span><b>Biaya penuh:</b> masukkan pakan, listrik, kandang, induk gagal, serta waktu perawatan.</span></li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section id="referensi" class="s-paper">
  <div class="wrap">
    <div class="sec-head reveal">
      <div class="sec-num"><span class="box">S.08</span> Referensi</div>
      <div>
        <h2>Sumber yang bisa <em>dilacak</em>.</h2>
        <p class="sp-jp lede">Setiap klaim di halaman ini berasal dari jurnal internasional terverifikasi. Berikut daftar lengkapnya.</p>
        <p class="sp-bt lede">Setiap klaim soal puyuh batu di halaman ini berasal dari literatur ilmiah terverifikasi (jurnal, IUCN Red List, buku ornitologi). Berikut daftar lengkapnya.</p>
      </div>
    </div>
    <ol class="sp-jp refs reveal">
      <li>Abudabos, A., dkk. (2025). <em>Animals</em> 15(23):3379. doi:10.3390/ani15233379 &mdash; mulai bertelur &plusmn;6 minggu; produksi 250&ndash;300 butir/tahun.</li>
      <li>Mokhtarzadeh, S., Nobakht, A., Lackner, M. (2022). <em>Animals</em> 12(20):2811. doi:10.3390/ani12202811 &mdash; puyuh: pakan efisien, ruang kecil, tahan penyakit.</li>
      <li>Bagh, J., dkk. (2016). Body weight, egg production, and egg quality traits of gray, brown, and white varieties of Japanese quail. PMC5021831 &mdash; telur = 8% bobot induk vs 3% ayam; nilai rujukan kualitas telur.</li>
      <li>Agboola, A.F., Omidiwura, B.R.O., Ologbosere, D.Y., Iyayi, E.A. (2017). <em>J. World Poult. Res.</em> 6(3):131&ndash;138 &mdash; ransum 20% protein kasar, 3.000 kkal/kg, konsumsi 20&ndash;35 g/ekor/hari.</li>
      <li>Sultana, F., Islam, M.S., Howlider, M.A.R. (2007). <em>Int. J. Poultry Sci.</em> 6(2):131&ndash;136. doi:10.3923/ijps.2007.131.136 &mdash; kalsium 2,5% untuk bobot &amp; kerabang; panen 2&times;/hari.</li>
      <li>Czerwonka, M., Białek, A. (2024). <em>Foods</em> 13(10):1571. doi:10.3390/foods13101571 &mdash; lemak telur puyuh: asam oleat &plusmn;40% total lemak.</li>
      <li>Romao, J.M., dkk. (2009). <em>Arch. Vet. Sci.</em> 14(3). doi:10.5380/avs.v14i3.14887 &mdash; suhu tetas 37&ndash;38&deg;C terbaik, RH &plusmn;55&ndash;60%.</li>
      <li>El-Tarabany, M.S. (2016). <em>J. Anim. Physiol. Anim. Nutr.</em> doi:10.1111/jpn.12404 &mdash; kepadatan 150&ndash;200 cm&sup2;/ekor menjaga produksi &amp; imun.</li>
      <li><em>J. Poult. Sci.</em> 42(2):130 (2005). J-STAGE &mdash; protein 16% menekan produksi telur.</li>
      <li>Vieira, D.V.G., dkk. (2015). <em>Semina: Ci&ecirc;nc. Agr&aacute;r.</em> 36(6):3965&ndash;3976. doi:10.5433/1679-0359.2015v36n6p3965 &mdash; 240 g protein/kg + elektrolit untuk albumen awet.</li>
      <li><em>Acta Sci. Anim. Sci.</em> 45 (2023). doi:10.4025/actascianimsci.v45i1.61040 &mdash; telur mengambang sejak hari ke-15 di suhu ruang; kualitas turun drastis 30 hari.</li>
      <li><em>J. Appl. Poult. Res.</em> (2022). S1056617122000447 &mdash; Haugh unit &gt;72 setelah 120 hari di 4&deg;C.</li>
      <li>Kumb&aacute;r, V., dkk. (2015). <em>J. Food Eng.</em> S0260877415002423 &mdash; kualitas internal baik sampai 16 minggu di 4&deg;C.</li>
      <li>Silva, dkk. (2020), dikutip dalam <em>Acta Sci. Anim. Sci.</em> 45 (2023) &mdash; suhu simpan ideal 10&ndash;15&deg;C, RH 70&ndash;80%.</li>
      <li><em>Boletim de Ind&uacute;stria Animal</em> 77:e1489 (2020). doi:10.17523/bia.2020.v77.e1489 &mdash; telur tanpa pendinginan kualitasnya lebih rendah.</li>
      <li>Altan, dkk.; KVFD (2010) &mdash; rentang literatur: shape index 70&ndash;80%, kerabang 0,20&ndash;0,30 mm, yolk index 42&ndash;48%, Haugh unit segar 85&ndash;95.</li>
      <li>Nisrina, N., Affandi, M.I., Marlina, L. (2022). Analisis Kelayakan Finansial Usaha Burung Puyuh Petelur. <em>Jurnal Ilmu Ternak</em> Unpad &mdash; pakan komponen biaya terbesar; kenaikan pakan 7%, produksi &minus;4%, atau harga &minus;4,1% membuat usaha tidak layak.</li>
      <li>Dewi, S., Rozalina, &amp; Basriwijaya, K.M.Z. (2023). <em>Jurnal Cakrawala Ilmiah</em> 2(9):3489&ndash;3496. doi:10.53625/jcijurnalcakrawalailmiah.v2i9.5664 &mdash; studi kasus Langsa: R/C 2,98, balik modal 3,5 bulan.</li>
      <li>Evisari, I.T., &amp; Kusumawati, R. (2024). <em>IKRAITH-EKONOMIKA</em> 7(3). doi:10.37817/ikraith-ekonomika.v7i3.4253 &mdash; Setu Farm: R/C 1,68, BEP harga Rp542/butir, BEP produksi 32.508 butir.</li>
      <li>Ningsih, Y., Nofrianil, &amp; Nefri, J. (2023). <em>JEPA</em> 7(2):536&ndash;546. ISSN 2614-4670 &mdash; Payakumbuh: harga pakan naik &amp; harga telur rendah; peternak beralih pakan adukan; R/C 1,76&ndash;2,45.</li>
      <li>Ratnasari, A., Sani, L.O.A., &amp; Hafid, H. (2017). <em>J. Ilmu dan Teknologi Peternakan Tropis</em> 4(1):28&ndash;36. doi:10.33772/jitro.v4i1.2721 &mdash; Kelompok Tunas Mekar Kendari layak secara finansial.</li>
      <li>Sanjaya, B., Amalia, &amp; Yasid, H. (2018). <em>Jurnal Ilmiah Pertanian</em> Unilak 13(1):47&ndash;58. ISSN 2502-5988 &mdash; harga telur puyuh cenderung turun saat Ramadhan.</li>
    </ol>
    <ol class="sp-bt refs reveal">
      <li>McGowan, P.J.K., &amp; Madge, S. (2010). <em>Pheasants, Partridges &amp; Grouse: Including buttonquails, sandgrouse and allies</em>. Bloomsbury. ISBN 978-1-4081-3565-5 &mdash; ukuran 12&ndash;15 cm &amp; 20&ndash;57 g; clutch 5&ndash;13 butir; rentang buku 18&ndash;23 hari; 1 butir/hari; sebaran Asia Tenggara&ndash;Australia.</li>
      <li>Adkins-Regan, E., dkk. (2016). Pairing Behavior of the Monogamous King Quail, <em>Coturnix chinensis</em>. <em>PLoS ONE</em> 11(6):e0155877. doi:10.1371/journal.pone.0155877 &mdash; sistem monogami dengan ikatan pasangan kuat.</li>
      <li>Tsudzuki, M. (1994). Excalfactoria Quail as a New Laboratory Research Animal. <em>Poultry Science</em> 73(6):763&ndash;768. doi:10.3382/ps.0730763 &mdash; puyuh batu sebagai hewan model penelitian.</li>
      <li>&Uuml;&ccedil;tepe, A. (2025). Blue-Breasted Quail (<em>Synoicus chinensis</em>): Characteristics, Breeding Techniques and Research. <em>Journal of Poultry Research</em> 22(1):24&ndash;39 &mdash; tinjauan teknik pemeliharaan, pakan, penyimpanan telur, serta penggunaan sebagai burung hobi dan hewan model.</li>
      <li>Wei, H.W., dkk. (2011). Estimating the requirement of dietary crude protein for growing blue-breasted quail. <em>Animal</em> 5(10):1506&ndash;1514. doi:10.1017/S1751731111000589 &mdash; umur 1&ndash;4 minggu: &gt;20,4% protein kasar pada 2.750 kkal/kg.</li>
      <li>Cai, J.H., Yeh, T.F., Wei, H.W., &amp; Liu, I.H. (2019). Temperature-induced embryonic diapause in blue-breasted quail. <em>Poultry Science</em> 98(7):2977&ndash;2988. doi:10.3382/ps/pez116 &mdash; ransum dewasa penelitian; suhu dan durasi simpan; inkubasi serta daya tetas.</li>
      <li>Ono, T., dkk. (2005). Culture system for embryos of blue-breasted quail from the blastoderm stage to hatching. <em>Experimental Animals</em> 54(1):7&ndash;11. doi:10.1538/expanim.54.7 &mdash; penyimpanan telur 12&ndash;14&deg;C maksimum 7 hari dalam protokol kultur embrio.</li>
      <li>Nakamura, Y., Nakane, Y., &amp; Tsudzuki, M. (2019). Developmental stages of the blue-breasted quail. <em>Animal Science Journal</em> 90(1):35&ndash;48. doi:10.1111/asj.13119 &mdash; penyimpanan 15&deg;C maksimum 5 hari dan perkembangan embrio sekitar 17 hari.</li>
      <li>Ramachandran, R., Dos Santos, M.N., &amp; McDaniel, C.D. (2019). Relationships among sperm-egg penetration, fertility and egg components of Chinese painted quail. <em>International Journal of Poultry Science</em> 18:101&ndash;108. doi:10.3923/ijps.2019.101.108 &mdash; fertilitas dan penyimpanan sperma lebih singkat dibanding Puyuh Jepang.</li>
      <li>BirdLife International (2016). <em>Synoicus chinensis</em>. The IUCN Red List of Threatened Species 2016: e.T22678979A92797212. doi:10.2305/IUCN.UK.2016-3.RLTS.T22678979A92797212.en &mdash; status Least Concern.</li>
      <li>Pappas, J. (n.d.). <em>Coturnix chinensis (blue-breasted quail or king quail)</em>. Animal Diversity Web, University of Michigan &mdash; ukuran 12,5&ndash;14 cm, bobot 28&ndash;40 g, betina lebih besar; perilaku &amp; perawatan.</li>
      <li>Pappas, J. (1996). Some observations on the behaviour and care of the Chinese Painted Quail. <em>The Avicultural Magazine</em> 102:102&ndash;105 &mdash; perawatan penangkaran: kandang tanah, sarang, pasangan.</li>
    </ol>
  </div>
</section>

<section id="kontak" class="contact">
  <div class="wrap">
    <span class="small">S.09 &mdash; Kontak</span>
    <h2>Mau diskusi soal puyuh, kandang, atau <em>ransum?</em></h2>
    <p class="sub">Pertanyaan, koreksi, atau sekadar tukar catatan &mdash; semua dibaca. Situs ini ditulis manual dari jurnal internasional, dan masukan pembaca ikut menjaga akurasinya.</p>
    <a class="pill" href="mailto:halo@wartapeternakan.xyz">halo@wartapeternakan.xyz <span class="ic">&rarr;</span></a>
    <div class="footnote">balasan dalam 1&ndash;2 hari kerja</div>
  </div>

</section>

<section id="saran" class="s-white">
  <div class="wrap">
    <div class="sec-head reveal">
      <div class="sec-num"><span class="box">S.10</span> Saran &amp; kritik</div>
      <div>
        <h2>Ada yang <em>kurang pas?</em></h2>
        <p class="lede">Koreksi fakta, usul topik, atau kritik tulisan ini &mdash; semua dibaca dan dipakai untuk perbaikan. Terima kasih sudah meluangkan waktu.</p>
      </div>
    </div>
    <form class="fb-form reveal" action="/feedback.php" method="post" id="fbForm">
      <input type="text" name="hp" class="fb-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
      <div class="fb-grid">
        <label class="fb-field"><span>Nama <i>(opsional)</i></span><input type="text" name="nama" maxlength="80" autocomplete="name" placeholder="Siapa kamu?"></label>
        <label class="fb-field"><span>Email <i>(opsional, untuk balasan)</i></span><input type="email" name="email" maxlength="120" autocomplete="email" inputmode="email" placeholder="kamu@contoh.com"></label>
      </div>
      <label class="fb-field"><span>Saran / kritik <i>(wajib)</i></span><textarea name="pesan" rows="5" maxlength="2000" required placeholder="Tulis saran atau kritikmu di sini&hellip;"></textarea></label>
      <div class="fb-foot">
        <button class="fb-btn" type="submit">Kirim saran <span class="arr">&rarr;</span></button>
        <span class="fb-status" id="fbStatus" role="status" aria-live="polite" tabindex="-1"></span>
      </div>
    </form>
  </div>
</section>

</main>

<footer>
  <div class="wrap">
    <div class="foot-in">
      <div class="foot-brand">
        <b>Warta Peternakan</b>
        <span class="sub">fokus: puyuh &amp; telur</span>
        <p>Catatan seputar puyuh: budidaya, telur, dan pakan. Ditulis manual dari jurnal internasional, tanpa template.</p>
      </div>
      <div class="foot-col">
        <h3>Navigasi</h3>
        <ul>
          <li><a href="#sekilas">Sekilas</a></li>
          <li><a href="#budidaya">Budidaya</a></li>
          <li><a href="#pakan">Pakan &amp; nutrisi</a></li>
          <li><a href="#kualitas">Kualitas telur</a></li>
          <li><a href="#simpan">Penyimpanan</a></li>
          <li><a href="#mitos">Mitos &amp; fakta</a></li>
          <li><a href="#usaha">Analisis usaha</a></li>
          <li><a href="#referensi">Referensi</a></li>
        </ul>
      </div>
      <div class="foot-col">
        <h3>Topik</h3>
        <ul>
          <li><a href="#sekilas">Coturnix japonica</a></li>
          <li><a href="#kualitas">Telur puyuh</a></li>
          <li><a href="#pakan">Ransum &amp; pakan</a></li>
          <li><a href="#kontak">Kontak</a></li>
        </ul>
      </div>
    </div>
    <div class="foot-base">
      <span>&copy; 2026 Warta Peternakan</span>
      <span>wartapeternakan.xyz &middot; <b id="visitCount">0</b> kunjungan</span>
    </div>
  </div>
</footer>

<script>
(function(){
  // hero entrance animation — langsung jalan saat halaman dimuat
  document.body.classList.add('intro-done');

  // theme toggle
  var html = document.documentElement;
  var themeBtn = document.getElementById('themeBtn');
  var saved = null;
  try { saved = localStorage.getItem('wp-theme'); } catch(e){}
  if (saved === 'dark') html.setAttribute('data-theme', 'dark');
  var syncIcon = function(){
    var dark = html.getAttribute('data-theme') === 'dark';
    themeBtn.innerHTML = dark ? '&#9728;' : '&#9681;';
    themeBtn.title = dark ? 'Mode terang' : 'Mode gelap';
    themeBtn.setAttribute('aria-label', dark ? 'Aktifkan mode terang' : 'Aktifkan mode gelap');
    themeBtn.setAttribute('aria-pressed', dark ? 'true' : 'false');
  };
  if (themeBtn) {
    syncIcon();
    themeBtn.addEventListener('click', function(){
      var dark = html.getAttribute('data-theme') === 'dark';
      var apply = function(){
        html.setAttribute('data-theme', dark ? 'light' : 'dark');
        try { localStorage.setItem('wp-theme', dark ? 'light' : 'dark'); } catch(e){}
        syncIcon();
      };
      // circle-wipe reveal dari posisi tombol (View Transitions API)
      var reduced = false;
      try { reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch(e){}
      if (document.startViewTransition && !reduced) {
        var r = themeBtn.getBoundingClientRect();
        html.style.setProperty('--vt-x', (r.left + r.width/2) + 'px');
        html.style.setProperty('--vt-y', (r.top + r.height/2) + 'px');
        html.classList.add('vt-running');
        var vt = document.startViewTransition(apply);
        if (vt && vt.finished) {
          vt.finished.then(function(){ html.classList.remove('vt-running'); }).catch(function(){ html.classList.remove('vt-running'); });
        } else {
          html.classList.remove('vt-running');
        }
      } else {
        apply();
      }
    });
  }

  // nav scroll state
  var nav = document.getElementById('topnav');
  var onScroll = function(){
    if (window.scrollY > 40) nav.classList.add('scrolled');
    else nav.classList.remove('scrolled');
    updateActiveLink();
  };
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();

  // mobile menu
  var btn = document.getElementById('menuBtn');
  var links = document.getElementById('navLinks');
  var setMenu = function(open){
    links.classList.toggle('open', open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    btn.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
    btn.innerHTML = open ? 'Tutup &#10005;' : 'Menu &#9776;';
  };
  btn.addEventListener('click', function(){ setMenu(!links.classList.contains('open')); });
  links.querySelectorAll('a').forEach(function(a){
    a.addEventListener('click', function(){ setMenu(false); });
  });
  document.addEventListener('keydown', function(e){
    if (e.key === 'Escape' && links.classList.contains('open')) { setMenu(false); btn.focus(); }
  });

  // tandai bagian yang sedang dibaca di navigasi
  var navAnchors = Array.prototype.slice.call(links.querySelectorAll('a[href^="#"]'));
  var pageSections = navAnchors.map(function(a){ return document.querySelector(a.getAttribute('href')); }).filter(Boolean);
  function updateActiveLink(){
    if (!navAnchors) return;
    var current = '';
    var marker = window.scrollY + 140;
    pageSections.forEach(function(section){
      if (section.offsetParent !== null && section.offsetTop <= marker) current = section.id;
    });
    navAnchors.forEach(function(a){
      var active = a.getAttribute('href') === '#' + current;
      a.classList.toggle('active', active);
      if (active) a.setAttribute('aria-current', 'location');
      else a.removeAttribute('aria-current');
    });
  }

  // reveal on scroll
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if (e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, {threshold:0.1, rootMargin:'0px 0px -40px 0px'});
  document.querySelectorAll('.reveal').forEach(function(el){ io.observe(el); });

  // feedback status setelah redirect
  var query = new URLSearchParams(location.search);
  var feedbackStatus = query.get('status');
  if (feedbackStatus) {
    var st = document.getElementById('fbStatus');
    if (st) {
      if (feedbackStatus === 'ok') st.textContent = 'Terkirim — terima kasih!';
      else if (feedbackStatus === 'terlalu-sering') st.textContent = 'Terlalu sering mengirim. Tunggu sebentar lalu coba lagi.';
      else st.textContent = 'Gagal kirim. Coba lagi, atau email langsung ke halo@wartapeternakan.xyz.';
      if (feedbackStatus !== 'ok') st.classList.add('err');
      query.delete('status');
      history.replaceState(null, '', location.pathname + (query.toString() ? '?' + query.toString() : '') + '#saran');
      var sbox = document.getElementById('saran');
      if (sbox) sbox.scrollIntoView({ block:'start' });
      st.focus();
    }
  }

  var fbForm = document.getElementById('fbForm');
  if (fbForm) fbForm.addEventListener('submit', function(){
    var submit = fbForm.querySelector('button[type="submit"]');
    if (submit) { submit.disabled = true; submit.textContent = 'Mengirim…'; }
  });

  // pemilih jenis puyuh
  var spSel = document.getElementById('spSel');
  var savedSp = null;
  try { savedSp = localStorage.getItem('wp-sp'); } catch(e){}
  var urlSp = new URLSearchParams(location.search).get('jenis');
  if (urlSp === 'bt' || (!urlSp && savedSp === 'bt')) spSel.value = 'bt';
  var defaultDescription = document.querySelector('meta[name="description"]').content;
  var applySp = function(sp, updateUrl){
    document.body.classList.toggle('sp-bt', sp === 'bt');
    // paksa reveal pada konten yang baru tampil (IntersectionObserver tidak trigger
    // untuk elemen yang display berubah dari none ke block)
    var vis = document.querySelectorAll('.sp-' + sp + ' .reveal, .sp-' + sp + '.reveal');
    vis.forEach(function(el){ el.classList.add('in'); });
    try { localStorage.setItem('wp-sp', sp); } catch(e){}
    document.title = sp === 'bt' ? 'Puyuh Batu — Habitat, Perawatan & Fakta | Warta Peternakan' : 'Puyuh — Catatan Budidaya, Telur & Ransum | Warta Peternakan';
    document.querySelector('meta[name="description"]').content = sp === 'bt' ? 'Puyuh batu (Excalfactoria chinensis): habitat, perilaku, perawatan, penetasan, dan fakta berdasarkan literatur ilmiah.' : defaultDescription;
    if (updateUrl) {
      var url = new URL(location.href);
      if (sp === 'bt') url.searchParams.set('jenis', 'bt');
      else url.searchParams.delete('jenis');
      history.replaceState(null, '', url.pathname + (url.searchParams.toString() ? '?' + url.searchParams.toString() : '') + url.hash);
    }
    updateActiveLink();
  };
  spSel.addEventListener('change', function(){ applySp(this.value, true); });
  applySp(spSel.value, true);

  // penghitung kunjungan
  var vc = document.getElementById('visitCount');
  if (vc) {
    fetch('counter.php', { method:'POST', credentials:'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(d){ if (d && typeof d.count === 'number') vc.textContent = d.count; })
      .catch(function(){});
  }
})();
</script>
</body>
</html>
