<?php
// ============================================================
// Penghitung kunjungan — wartapeternakan.xyz
// Menghitung IP unik per hari (refresh tidak menambah angka).
// Data disimpan di /home/warta306/counter/visits.json (di luar docroot).
//
//  GET  /counter.php  -> baca jumlah (tanpa menambah)
//  POST /counter.php  -> catat kunjungan + balas jumlah terbaru
// ============================================================
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$FILE = '/home/warta306/counter/visits.json';

// ---- filter bot dasar ----
$ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
$bot = 'bot|crawler|spider|slurp|bing|baidu|yandex|semrush|ahrefs|majestic|facebookexternalhit|whatsapp|telegram|petalbot|bytespider|headless|curl|wget|python|acme|letsencrypt|checker|cpanel|monitor|uptime|pingdom|dotbot|mj12|archive|scrapy|phantom|pinterest';
if (preg_match('/' . $bot . '/', $ua)) {
    echo json_encode(['count' => 0, 'bot' => true]);
    exit;
}

function read_count($f) {
    if (!file_exists($f)) return ['total' => 0, 'today' => '', 'today_ips' => []];
    $d = json_decode(@file_get_contents($f), true);
    return is_array($d) ? $d : ['total' => 0, 'today' => '', 'today_ips' => []];
}

$data = read_count($FILE);
$today = date('Y-m-d');

// reset IP harian kalau sudah ganti hari
if ($data['today'] !== $today) {
    $data['today'] = $today;
    $data['today_ips'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    if ($ip !== '' && !isset($data['today_ips'][$ip])) {
        $data['today_ips'][$ip] = 1;
        $data['total'] = intval($data['total']) + 1;
        @mkdir(dirname($FILE), 0755, true);
        @file_put_contents($FILE, json_encode($data), LOCK_EX);
    }
}

echo json_encode([
    'count' => intval($data['total']),
    'today' => is_array($data['today_ips']) ? count($data['today_ips']) : 0,
    'bot' => false,
]);
