<?php
// Saran & kritik — wartapeternakan.xyz
// POST: nama, email, pesan, hp (honeypot)
// Simpan di luar docroot dan kirim notifikasi melalui SMTP.

declare(strict_types=1);

const FEEDBACK_DIR = '/home/warta306/feedback';
const FEEDBACK_FILE = FEEDBACK_DIR . '/saran.json';
const RATE_FILE = FEEDBACK_DIR . '/rate-limit.json';
const SMTP_CONFIG_FILE = '/home/warta306/feedback/smtp-config.php';

function redirect_status(string $status): void {
    header('Location: /?status=' . rawurlencode($status), true, 303);
    exit;
}

function env_value(string $name): string {
    $value = getenv($name);
    return is_string($value) ? trim($value) : '';
}

function smtp_config(): array {
    $fileConfig = [];
    $configPath = env_value('WP_SMTP_CONFIG');
    if ($configPath === '') {
        $configPath = SMTP_CONFIG_FILE;
    }

    if (is_readable($configPath)) {
        $loaded = require $configPath;
        if (is_array($loaded)) {
            $fileConfig = $loaded;
        }
    }

    $host = env_value('WP_SMTP_HOST');
    $port = env_value('WP_SMTP_PORT');
    $user = env_value('WP_SMTP_USER');
    $pass = env_value('WP_SMTP_PASSWORD');

    return [
        'host' => $host !== '' ? $host : (string)($fileConfig['host'] ?? ''),
        'port' => (int)($port !== '' ? $port : ($fileConfig['port'] ?? 465)),
        'user' => $user !== '' ? $user : (string)($fileConfig['user'] ?? ''),
        'pass' => $pass !== '' ? $pass : (string)($fileConfig['pass'] ?? ''),
    ];
}

function smtp_read($socket): string {
    $response = '';
    while (($line = fgets($socket, 512)) !== false) {
        $response .= $line;
        if (isset($line[3]) && $line[3] === ' ') {
            break;
        }
    }
    return $response;
}

function smtp_code(string $response): int {
    return (int)substr($response, 0, 3);
}

function smtp_command($socket, string $command): string {
    if (fwrite($socket, $command . "\r\n") === false) {
        return '';
    }
    return smtp_read($socket);
}

function smtp_send(string $to, string $subject, string $body, string $replyTo = ''): bool {
    $smtp = smtp_config();
    if ($smtp['host'] === '' || $smtp['port'] < 1 || $smtp['user'] === '' || $smtp['pass'] === '') {
        error_log('Warta Peternakan: konfigurasi SMTP belum tersedia.');
        return false;
    }

    $socket = @stream_socket_client(
        'ssl://' . $smtp['host'] . ':' . $smtp['port'],
        $errno,
        $errstr,
        15,
        STREAM_CLIENT_CONNECT
    );
    if (!$socket) {
        error_log('Warta Peternakan: koneksi SMTP gagal.');
        return false;
    }
    stream_set_timeout($socket, 15);

    $ok = smtp_code(smtp_read($socket)) === 220
        && smtp_code(smtp_command($socket, 'EHLO wartapeternakan.xyz')) === 250
        && smtp_code(smtp_command($socket, 'AUTH LOGIN')) === 334
        && smtp_code(smtp_command($socket, base64_encode($smtp['user']))) === 334
        && smtp_code(smtp_command($socket, base64_encode($smtp['pass']))) === 235
        && smtp_code(smtp_command($socket, 'MAIL FROM:<' . $smtp['user'] . '>')) === 250
        && smtp_code(smtp_command($socket, 'RCPT TO:<' . $to . '>')) === 250
        && smtp_code(smtp_command($socket, 'DATA')) === 354;

    if (!$ok) {
        fclose($socket);
        error_log('Warta Peternakan: autentikasi atau perintah SMTP gagal.');
        return false;
    }

    $safeSubject = str_replace(["\r", "\n"], ' ', $subject);
    $encodedSubject = '=?UTF-8?B?' . base64_encode($safeSubject) . '?=';
    $safeReplyTo = filter_var($replyTo, FILTER_VALIDATE_EMAIL) ? $replyTo : $smtp['user'];
    $headers = "From: Warta Peternakan <{$smtp['user']}>\r\n"
        . "Reply-To: {$safeReplyTo}\r\n"
        . "MIME-Version: 1.0\r\n"
        . "Content-Type: text/plain; charset=UTF-8\r\n"
        . "Content-Transfer-Encoding: 8bit\r\n";

    $normalizedBody = str_replace(["\r\n", "\r"], "\n", $body);
    $normalizedBody = preg_replace('/^\./m', '..', $normalizedBody) ?? $normalizedBody;
    $normalizedBody = str_replace("\n", "\r\n", $normalizedBody);
    $data = "Subject: {$encodedSubject}\r\n{$headers}\r\n{$normalizedBody}";

    fwrite($socket, $data . "\r\n.\r\n");
    $sent = smtp_code(smtp_read($socket)) === 250;
    smtp_command($socket, 'QUIT');
    fclose($socket);

    if (!$sent) {
        error_log('Warta Peternakan: server SMTP menolak isi pesan.');
    }
    return $sent;
}

function ensure_feedback_dir(): bool {
    return is_dir(FEEDBACK_DIR) || @mkdir(FEEDBACK_DIR, 0750, true);
}

function client_key(): string {
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
    return hash('sha256', $ip . '|' . $ua);
}

function rate_limit_allows(int $limit = 3, int $windowSeconds = 900): bool {
    if (!ensure_feedback_dir()) {
        return false;
    }

    $handle = @fopen(RATE_FILE, 'c+');
    if (!$handle || !flock($handle, LOCK_EX)) {
        if ($handle) {
            fclose($handle);
        }
        return false;
    }

    $raw = stream_get_contents($handle);
    $data = json_decode($raw !== false ? $raw : '', true);
    if (!is_array($data)) {
        $data = [];
    }

    $now = time();
    $cutoff = $now - $windowSeconds;
    foreach ($data as $key => $timestamps) {
        if (!is_array($timestamps)) {
            unset($data[$key]);
            continue;
        }
        $data[$key] = array_values(array_filter(
            $timestamps,
            static fn($timestamp): bool => is_int($timestamp) && $timestamp >= $cutoff
        ));
        if ($data[$key] === []) {
            unset($data[$key]);
        }
    }

    $key = client_key();
    $recent = $data[$key] ?? [];
    $allowed = count($recent) < $limit;
    if ($allowed) {
        $recent[] = $now;
        $data[$key] = $recent;
    }

    rewind($handle);
    ftruncate($handle, 0);
    fwrite($handle, json_encode($data, JSON_UNESCAPED_SLASHES));
    fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
    @chmod(RATE_FILE, 0640);

    return $allowed;
}

function append_feedback(array $entry): bool {
    if (!ensure_feedback_dir()) {
        return false;
    }

    $handle = @fopen(FEEDBACK_FILE, 'c+');
    if (!$handle || !flock($handle, LOCK_EX)) {
        if ($handle) {
            fclose($handle);
        }
        return false;
    }

    $raw = stream_get_contents($handle);
    $data = json_decode($raw !== false ? $raw : '', true);
    if (!is_array($data)) {
        $data = [];
    }
    $data[] = $entry;

    $encoded = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $saved = false;
    if ($encoded !== false) {
        rewind($handle);
        ftruncate($handle, 0);
        $saved = fwrite($handle, $encoded) !== false;
        fflush($handle);
    }

    flock($handle, LOCK_UN);
    fclose($handle);
    @chmod(FEEDBACK_FILE, 0640);
    return $saved;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Location: /', true, 303);
    exit;
}

$origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
if ($origin !== '' && parse_url($origin, PHP_URL_HOST) !== 'wartapeternakan.xyz') {
    redirect_status('gagal');
}

$nama = trim(substr((string)($_POST['nama'] ?? ''), 0, 80));
$email = trim(substr((string)($_POST['email'] ?? ''), 0, 120));
$pesan = trim(substr((string)($_POST['pesan'] ?? ''), 0, 2000));
$honeypot = trim((string)($_POST['hp'] ?? ''));

if ($honeypot !== '') {
    redirect_status('ok');
}
if ($pesan === '' || ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL))) {
    redirect_status('gagal');
}
if (!rate_limit_allows()) {
    redirect_status('terlalu-sering');
}

$safeName = trim(str_replace(["\r", "\n"], ' ', $nama));
$entry = [
    'waktu' => date('c'),
    'nama' => $safeName,
    'email' => $email,
    'pesan' => $pesan,
];

if (!append_feedback($entry)) {
    redirect_status('gagal');
}

$subject = '[Saran Warta Peternakan] ' . ($safeName !== '' ? $safeName : 'Anonim');
$body = "Nama: {$safeName}\nEmail: {$email}\n\nPesan:\n{$pesan}\n";
smtp_send('halo@wartapeternakan.xyz', $subject, $body, $email);

redirect_status('ok');
