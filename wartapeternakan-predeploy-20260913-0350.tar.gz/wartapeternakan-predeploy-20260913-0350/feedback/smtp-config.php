<?php
return [
    'host' => 'mail.wartapeternakan.xyz',
    'port' => 465,
    'user' => 'halo@wartapeternakan.xyz',
    'pass' => 'Nkri1945!',
];
